import { system, world } from "@minecraft/server";
import SpawnData from "Data/SpawnData";
import DeathMessageHelper from "Helpers/DeathMessageHelper";
import V3 from "Helpers/Vectors/V3";
import HomeHelper from "Homes/HomeHelper";
import InventoryHelper from "Inventory/InventoryHelper";
import SkinRandomizerComponent from "SkinRandomizer/SkinRandomizerComponent";
import VirtualServerManager from "VirtualServer/VirtualServerManager";
import PlayerTrailComponent from "./PlayerTrailComponent";

class SpawnManager {
    static init() {
        EventSubscriber.subscribe("WorldAfterEvents", "entityDie", this.onEntityDie.bind(this));
        EventSubscriber.subscribe("SystemBeforeEvents", "shutdown", this.onShutdown.bind(this));
        
        // --- AUTO-JOIN ON PLAYER SPAWN ---
        world.afterEvents.playerSpawn.subscribe((event) => {
            const { player, initialSpawn } = event;
            if (!initialSpawn) return;

            system.runTimeout(() => {
                const dim = player.dimension;
                const existingBots = dim.getEntities({ type: "gm1_sky:aip" });

                if (existingBots.length === 0) {
                    const spawnPos = new V3(
                        Math.floor(player.location.x) + 1,
                        Math.floor(player.location.y),
                        Math.floor(player.location.z) + 1
                    );
                    
                    // Fallback to active serialized bot profile or spawn fresh
                    const tags = Object.keys(SpawnManager.serializedAIPs);
                    const chosenTag = tags.length > 0 ? tags[0] : "Companion";
                    
                    SpawnManager.trySpawnAtLocation(spawnPos, chosenTag);
                }
            }, 30);
        });
        // ---------------------------------

        this.serializedAIPs = this.loadSerializedAIPs();
        this.spawnQueue = this.loadSpawnQueue();
        system.runInterval(this.onTick.bind(this), 1);
    }

    static onShutdown() {
        this.saveSerializedAIPs();
        this.saveSpawnQueue();
    }

    static onTick() {
        if (Main.currentTick % SpawnData.SpawnCheckInterval !== 0) return;
        if (VirtualServerManager.serverStatus === "offline") return;
        this.processLoadQueue();
        this.processSpawnQueue();
    }

    static onEntityDie(event) {
        if (event.deadEntity?.typeId !== "gm1_sky:aip") return;
        DeathMessageHelper.broadcastDeathMessage(event);
        // Do not respawn in game tests
        if (event.deadEntity.gameTestData) return;

        // Neutralized: Profile will not simulated-leave upon dying
        // if (VirtualServerManager.tryRandomLeaveOnDeath(event.deadEntity)) return;

        const serializedAIP = this.serializeAIPFromEntity(event.deadEntity, false);
        this.queueRespawn(serializedAIP);
        const location = V3.fromEntity(event.deadEntity, overworld);
        // Try immediate respawn after a short delay
        system.runTimeout(() => {
            const respawnLocation = this.resolveInstantRespawnLocation(location);
            if (!respawnLocation) return;
            this.trySpawnAtLocation(respawnLocation, serializedAIP.tag);
        }, SpawnData.InstantRespawnDuration);
    }

    // #region Load queue
    static queueLoad(serializedAIP, location, maxTime = 0) {
        this.setSerializedAIP(serializedAIP.tag, serializedAIP);
        this.loadQueue[serializedAIP.tag] = {
            maxTime: Main.currentTick + maxTime,
            location
        };
        this.queueRespawn(serializedAIP);
    }

    static processLoadQueue() {
        for (const [tag, entry] of Object.entries(this.loadQueue)) {
            if (Main.currentTick >= entry.maxTime) {
                this.deleteFromLoadQueue(tag);
                continue;
            }
            this.trySpawnAtLocation(entry.location, tag);
        }
    }

    static deleteFromLoadQueue(gamerTag) {
        if (gamerTag in this.loadQueue) delete this.loadQueue[gamerTag];
    }
    // #endregion

    // #region Spawn queue
    static queueRespawn(serializedAIP) {
        const randomTime = MathUtil.randomInt(SpawnData.MinimumRespawnDuration, SpawnData.MaximumRespawnDuration);
        this.queueSpawn(serializedAIP, randomTime);
    }

    static queueSpawn(serializedAIP, minDelay = 0) {
        this.setSerializedAIP(serializedAIP.tag, serializedAIP);
        this.spawnQueue[serializedAIP.tag] = Main.currentTick + minDelay;
    }

    static processSpawnQueue() {
        for (const [tag, minTime] of Object.entries(this.spawnQueue)) {
            if (Main.currentTick < minTime) continue;
            const success = this.trySpawnNearValidPlayer(tag);
            if (success) break; // Only process one AIP per interval
        }
    }

    static saveSpawnQueue() {
        world.setDynamicProperty(this.SpawnQueueKey, JSON.stringify(this.spawnQueue));
    }

    static loadSpawnQueue() {
        const data = world.getDynamicProperty(this.SpawnQueueKey);
        if (!data) return {};
        return JSON.parse(data);
    }

    static deleteFromSpawnQueue(gamerTag) {
        if (gamerTag in this.spawnQueue) delete this.spawnQueue[gamerTag];
    }
    // #endregion

    // #region Serialization
    static serializeAIPFromEntity(entity, saveInventory) {
        const gamerTag = EntityStore.get(entity, "gamerTag");
        const entityStore = this.getEntityStoreData(entity);
        const inventory = saveInventory ? this.serializeInventorySnapshot(InventoryHelper.getInventorySnapshot(entity)) : [];
        return {
            tag: gamerTag,
            entityStore,
            inventory
        };
    }

    static getSerializedAIP(tag) {
        return this.serializedAIPs[tag] ?? {
            tag
        };
    }

    static setSerializedAIP(tag, serializedAIP) {
        this.serializedAIPs[tag] = serializedAIP;
    }

    static deleteSerializedAIP(tag) {
        this.deleteFromLoadQueue(tag);
        this.deleteFromSpawnQueue(tag);
        delete this.serializedAIPs[tag];
    }

    static saveSerializedAIPs() {
        world.setDynamicProperty(this.SerializedAIPsKey, JSON.stringify(this.serializedAIPs));
    }

    static loadSerializedAIPs() {
        const data = world.getDynamicProperty(this.SerializedAIPsKey);
        if (!data) return {};
        return JSON.parse(data);
    }
    // #endregion

    // #region Spawning & Despawning
    static resolveInstantRespawnLocation(location) {
        const homeSpawnLocation = HomeHelper.getValidHomeSpawnLocation(location);
        if (homeSpawnLocation) return homeSpawnLocation;
        const worldSpawn = new V3(world.getDefaultSpawnLocation());
        // Set y axis to 0 as getDefaultSpawnLocation returns y with max int
        if (!worldSpawn.$.setAxis("y", 0).isLoaded()) return null;
        const topMostBlock = overworld.getTopmostBlock(worldSpawn);
        if (!topMostBlock) return null;
        return worldSpawn.$.setAxis("y", topMostBlock.location.y + 1);
    }

    static trySpawnNearValidPlayer(gamerTag) {
        const players = EntityUtil.getPlayers();
        if (players.length === 0) return false;
        const player = MathUtil.choose(players);
        const spawnLocation = PlayerTrailComponent.getBestSpawnLocation(player);
        if (!spawnLocation) return false;
        if (spawnLocation.dimension?.id !== overworld.id) return false;
        return !!this.spawnSerializedAIP(spawnLocation, this.getSerializedAIP(gamerTag));
    }

    static trySpawnAtLocation(location, gamerTag) {
        if (!this.isWithinSpawnDistanceOfAnyPlayer(location)) return false;
        return this.spawnSerializedAIP(location, this.getSerializedAIP(gamerTag));
    }

    static spawnSerializedAIP(location, serializedAIP) {
        var _serializedAIP;
        this.deleteSerializedAIP(serializedAIP.tag);
        // Check if entity with gamertag already exists
        const profile = VirtualServerManager.getProfileFromGamerTag(serializedAIP.tag);
        if (profile) {
            const entity = VirtualServerManager.getEntityFromProfile(profile);
            if (entity) return entity;
            if (profile.status !== "online") return false;
        }
        const dimension = location.dimension ?? overworld;
        const entity = dimension.spawnEntity("gm1_sky:aip", location);
        (_serializedAIP = serializedAIP).entityStore ?? (_serializedAIP.entityStore = {});
        serializedAIP.entityStore.gamerTag = serializedAIP.tag;
        entity.nameTag = serializedAIP.tag;
        this.setEntityStoreData(entity, serializedAIP.entityStore);
        this.tryRestoreSkinFromEntityStore(entity);
        const inventory = serializedAIP.inventory ?? [];
        if (inventory.length > 0) {
            system.run(() => {
                if (!entity.isValid) return;
                const deserializedInventory = this.deserializeInventorySnapshot(inventory);
                InventoryHelper.restoreInventorySnapshot(entity, deserializedInventory);
            });
        }
        return entity;
    }

    static isWithinSpawnDistanceOfAnyPlayer(location) {
        const players = EntityUtil.getPlayers();
        for (const player of players) {
            const playerLocation = V3.fromEntity(player, true);
            if (player.dimension.id !== overworld.id) continue;
            const distance = location.distance(playerLocation);
            if (distance <= SpawnData.MaximumSpawnDistanceFromPlayer) return true;
        }
        return false;
    }

    static despawn(entity) {
        const serializedAIP = this.serializeAIPFromEntity(entity, true);
        this.setSerializedAIP(serializedAIP.tag, serializedAIP);
        entity.remove();
        return serializedAIP;
    }

    static leave(tag) {
        this.deleteFromSpawnQueue(tag);
        this.deleteFromLoadQueue(tag);
    }
    // #endregion

    // #region Entity Store
    static getEntityStoreData(entity) {
        const store = {};
        for (const key of SpawnData.SavedEntityStoreKeys) {
            const value = EntityStore.get(entity, key);
            if (!SpawnManager.isPropertyValue(value)) continue;
            store[key] = value;
        }
        return store;
    }

    static setEntityStoreData(target, entityStore) {
        for (const key of SpawnData.SavedEntityStoreKeys) {
            const value = entityStore[key];
            if (value === undefined) continue;
            EntityStore.set(target, key, value);
        }
    }

    static tryRestoreSkinFromEntityStore(entity) {
        if (EntityStore.get(entity, "baseSkin") === SkinRandomizerComponent.UNDEFINED_SKIN) return;
        entity.setProperty("gm1_sky:bodytype", EntityStore.get(entity, "bodytypeSkin"));
        entity.setProperty("gm1_sky:base", EntityStore.get(entity, "baseSkin"));
        entity.setProperty("gm1_sky:shirt", EntityStore.get(entity, "shirtSkin"));
        entity.setProperty("gm1_sky:pants", EntityStore.get(entity, "pantsSkin"));
        entity.setProperty("gm1_sky:eyes", EntityStore.get(entity, "eyesSkin"));
        entity.setProperty("gm1_sky:eyes_color", EntityStore.get(entity, "eyesColorSkin"));
        entity.setProperty("gm1_sky:mouth", EntityStore.get(entity, "mouthSkin"));
        entity.setProperty("gm1_sky:mouth_color", EntityStore.get(entity, "mouthColorSkin"));
        entity.setProperty("gm1_sky:hair", EntityStore.get(entity, "hairSkin"));
        entity.setProperty("gm1_sky:hair_color", EntityStore.get(entity, "hairColorSkin"));
    }

    static isPropertyValue(value) {
        return typeof value === "string" || typeof value === "number" || typeof value === "boolean";
    }
    // #endregion

    // #region Inventory
    static serializeInventorySnapshot(inventorySnapshot) {
        const serializedInventory = [];
        for (const item of inventorySnapshot) {
            if (!item) continue;
            serializedInventory.push(InventoryUtil.serializeItemStack(item));
        }
        return serializedInventory;
    }

    static deserializeInventorySnapshot(serializedInventory) {
        const deserializedInventory = [];
        for (const item of serializedInventory) {
            deserializedInventory.push(InventoryUtil.deserializeItemStack(item));
        }
        return deserializedInventory;
    }
}

SpawnManager.SerializedAIPsKey = "gm1_sky:serialized_aips";
SpawnManager.SpawnQueueKey = "gm1_sky:spawn_queue";
SpawnManager.serializedAIPs = {};
SpawnManager.spawnQueue = {};
SpawnManager.loadQueue = {};

export { SpawnManager as default };
