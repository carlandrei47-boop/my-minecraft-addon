import "GlobalVars";
import "Typing/Prototypes/Console";
import "Typing/Prototypes/Entity";
import "Typing/Prototypes/System";
import { system, world, ItemStack } from "@minecraft/server";
import SpawnManager from "AIPSpawner/SpawnManager";
import CommandManager from "Commands/CommandManager";
import ComponentManager from "Components/ComponentManager";
import EnemyManager from "Enemy/EnemyManager";
import FeatureCache from "FeatureCache/FeatureCache";
import MobComponentManager from "MobComponents/MobComponentManager";
import ScriptEventListener from "Systems/ScriptEvents/ScriptEventListener";
import Env from "Env";
import TriggerManager from "Trigger/TriggerManager";
import VirtualServerManager from "VirtualServer/VirtualServerManager";

// --- CUSTOM SURVIVAL PARTNER UTILITIES ---
import { BaseGuard } from "Utils/BaseGuard";
import { CraterPatcher } from "Utils/CraterPatcher";
import { CorpseCourier } from "Utils/CorpseCourier";
import { RecipeCrafter } from "Utils/RecipeCrafter";
import { StructureBuilder } from "Utils/StructureBuilder";
import { GoFarmingProcedure } from "BigBrain/Procedures/GoFarmingProcedure";
import { NightSurvivalProcedure } from "BigBrain/Procedures/NightSurvivalProcedure";
import { BuildHomeProcedure } from "BigBrain/Procedures/BuildHomeProcedure";

class _Main {
    static init() {
        system.runInterval(() => this.onTick());
        EventSubscriber.subscribe("WorldAfterEvents", "worldLoad", () => this.onWorldLoad());
        EventSubscriber.subscribe("SystemBeforeEvents", "startup", this.onStartup.bind(this));
        EventSubscriber.subscribe("SystemBeforeEvents", "shutdown", this.onShutdown.bind(this));
        const events = new EventEmitter();
        globalThis.CustomEvents = events;
    }

    static async onStartup(event) {
        CommandManager.init(event.customCommandRegistry);
        ComponentManager.init(event.blockComponentRegistry, event.itemComponentRegistry);
    }

    static async tryInitTestManager() {
        try {
            const TestManager = (await import("Test/TestManager")).default;
            TestManager.init();
        } catch (error) {
            console.error(error);
        }
    }

    static onShutdown() {
        this.isShuttingDown = true;
    }

    static initPreliminarySystems() {
        Config.init();
        PlayersCache.init();
        EntityStore.init();
        ScriptEventListener.init();
        EnemyManager.init();
    }

    static initFinalSystems() {
        FeatureCache.init();
        MobComponentManager.init();
        TriggerManager.init();
        VirtualServerManager.init();
        SpawnManager.init();

        // Initialize custom modules
        BaseGuard.init();
        CraterPatcher.init();
        CorpseCourier.init();
        RecipeCrafter.init();
        StructureBuilder.init(); // <--- StructureBuilder engine initialization
    }

    static onWorldLoad() {
        globalThis.overworld = world.getDimension("overworld");
        globalThis.nether = world.getDimension("nether");
        globalThis.theEnd = world.getDimension("the end");
        globalThis.isEditorWorld = system.isEditorWorld;
        this.dimensions.overworld = globalThis.overworld;
        this.dimensions.nether = globalThis.nether;
        this.dimensions.theEnd = globalThis.theEnd;
        this.initPreliminarySystems();
        this.initFinalSystems();
    }

    static onTick() {
        this.currentTick = system.currentTick;

        // Companion behavior check runs every 40 ticks (2 seconds)
        if (this.currentTick % 40 === 0 && globalThis.overworld) {
            try {
                const bots = globalThis.overworld.getEntities({ type: "gm1_sky:aip" });
                for (const bot of bots) {
                    if (!bot.isValid) continue;

                    // 1. Auto-compact bulk ores and craft essential gear
                    RecipeCrafter.checkAndCraft(bot);

                    // 2. Village & terrain hay bale scanning (harvests and turns into bread)
                    this.processHayBalesForFood(bot);

                    // 3. Night 1 / dusk survival logic
                    const nightProcedure = new NightSurvivalProcedure();
                    nightProcedure.context = { entity: bot };
                    nightProcedure.onActiveTick();

                    // 4. Crop farming, anti-trample sneaking, and replanting
                    const farmProcedure = new GoFarmingProcedure();
                    farmProcedure.context = { entity: bot };
                    farmProcedure.onActiveTick();

                    // 5. Gated Starter Cabin / Tome Tower Building (only builds if given order:settle)
                    const buildProcedure = new BuildHomeProcedure();
                    buildProcedure.context = { entity: bot };
                    buildProcedure.onActiveTick();
                }
            } catch {}
        }
    }

    /**
     * Scans for nearby hay bales in villages/plains, breaks them, and feeds inventory
     */
    static processHayBalesForFood(bot) {
        const inv = bot.getComponent("minecraft:inventory")?.container;
        if (!inv) return;

        const loc = bot.location;
        const dim = bot.dimension;

        for (let dx = -3; dx <= 3; dx++) {
            for (let dz = -3; dz <= 3; dz++) {
                for (let dy = -1; dy <= 2; dy++) {
                    const blockPos = {
                        x: Math.floor(loc.x) + dx,
                        y: Math.floor(loc.y) + dy,
                        z: Math.floor(loc.z) + dz
                    };
                    const block = dim.getBlock(blockPos);
                    if (block && block.typeId === "minecraft:hay_block") {
                        dim.runCommand(`setblock ${blockPos.x} ${blockPos.y} ${blockPos.z} air destroy`);
                        return;
                    }
                }
            }
        }
    }
}

_Main.currentTick = 0;
_Main.isShuttingDown = false;
_Main.dimensions = {};

export { _Main as default };
globalThis.Main = _Main;
Main.init();
if (Env !== "prod") Main.tryInitTestManager();
