import { world, system } from "@minecraft/server";
import { BaseGuard } from "./BaseGuard.js";

export class CraterPatcher {
    static init() {
        world.afterEvents.explosion.subscribe((event) => {
            const dim = event.dimension;
            const impactedBlocks = event.getImpactedBlocks();
            if (!impactedBlocks || impactedBlocks.length === 0) return;

            system.runTimeout(() => {
                for (const block of impactedBlocks) {
                    const loc = block.location;
                    const inBase = BaseGuard.isInsideProtectedZone(loc, dim);

                    if (inBase) {
                        try {
                            dim.runCommand(`setblock ${loc.x} ${loc.y} ${loc.z} cobblestone keep`);
                        } catch {}
                    } else {
                        try {
                            const below = dim.getBlock({ x: loc.x, y: loc.y - 1, z: loc.z });
                            if (below && !below.isAir) {
                                dim.runCommand(`setblock ${loc.x} ${loc.y} ${loc.z} dirt keep`);
                            }
                        } catch {}
                    }
                }
            }, 20);
        });
    }
}
