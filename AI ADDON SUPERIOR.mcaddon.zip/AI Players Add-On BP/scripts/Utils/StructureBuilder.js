import { world, system, Vector3 } from "@minecraft/server";
import { VirtualInventoryComponent } from "../Inventory/VirtualInventoryComponent";

export class StructureBuilder {
    static activeBuilds = new Map();

    static startBuilding(bot, structureName) {
        const dim = bot.dimension;
        const startPos = { 
            x: Math.floor(bot.location.x), 
            y: Math.floor(bot.location.y), 
            z: Math.floor(bot.location.z) 
        };

        // Track the building state for this bot
        this.activeBuilds.set(bot.id, {
            structureName,
            dimension: dim,
            origin: startPos,
            currentIndex: 0,
            isBuilding: true
        });
        
        bot.sendMessage("Starting to construct the Tome Tower!");
    }

    static tick() {
        for (const [botId, build] of this.activeBuilds.entries()) {
            const bot = world.getEntity(botId);
            if (!bot || !build.isBuilding) {
                this.activeBuilds.delete(botId);
                continue;
            }

            // Here we process the next block in the sequence each tick or interval
            // (Companions check inventory, walk to position, and place)
        }
    }
}

// Register the builder loop into the global system tick
system.runInterval(() => {
    StructureBuilder.tick();
}, 20); // Runs once every second
