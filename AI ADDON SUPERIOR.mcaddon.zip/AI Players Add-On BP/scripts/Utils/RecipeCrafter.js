import { ItemStack } from "@minecraft/server";

export class RecipeCrafter {
    static init() {
        this.recipes = [
            // Survival Essentials
            { result: "minecraft:crafting_table", count: 1, ingredients: [{ id: "minecraft:planks", count: 4 }] },
            { result: "minecraft:stick", count: 4, ingredients: [{ id: "minecraft:planks", count: 2 }] },
            { result: "minecraft:torch", count: 4, ingredients: [{ id: "minecraft:coal", count: 1 }, { id: "minecraft:stick", count: 1 }] },
            { result: "minecraft:chest", count: 1, ingredients: [{ id: "minecraft:planks", count: 8 }] },
            { result: "minecraft:furnace", count: 1, ingredients: [{ id: "minecraft:cobblestone", count: 8 }] },

            // Combat & Defense
            { result: "minecraft:shield", count: 1, ingredients: [{ id: "minecraft:planks", count: 6 }, { id: "minecraft:iron_ingot", count: 1 }] },
            { result: "minecraft:bucket", count: 1, ingredients: [{ id: "minecraft:iron_ingot", count: 3 }] },

            // Food & Farming
            { result: "minecraft:bread", count: 1, ingredients: [{ id: "minecraft:wheat", count: 3 }] },
            { result: "minecraft:golden_apple", count: 1, ingredients: [{ id: "minecraft:apple", count: 1 }, { id: "minecraft:gold_ingot", count: 8 }] }
        ];

        // 9-to-1 Compression Dictionary
        this.compactables = [
            { raw: "minecraft:raw_iron", block: "minecraft:raw_iron_block" },
            { raw: "minecraft:iron_ingot", block: "minecraft:iron_block" },
            { raw: "minecraft:raw_gold", block: "minecraft:raw_gold_block" },
            { raw: "minecraft:gold_ingot", block: "minecraft:gold_block" },
            { raw: "minecraft:raw_copper", block: "minecraft:raw_copper_block" },
            { raw: "minecraft:copper_ingot", block: "minecraft:copper_block" },
            { raw: "minecraft:coal", block: "minecraft:coal_block" },
            { raw: "minecraft:redstone", block: "minecraft:redstone_block" },
            { raw: "minecraft:lapis_lazuli", block: "minecraft:lapis_block" },
            { raw: "minecraft:diamond", block: "minecraft:diamond_block" },
            { raw: "minecraft:emerald", block: "minecraft:emerald_block" },
            { raw: "minecraft:wheat", block: "minecraft:hay_block" }
        ];
    }

    /**
     * Compresses raw stacks of 9+ into solid blocks
     */
    static autoCompact(entity) {
        if (!entity?.isValid) return;
        const inv = entity.getComponent("minecraft:inventory")?.container;
        if (!inv) return;

        for (const itemDef of this.compactables) {
            let total = 0;
            for (let i = 0; i < inv.size; i++) {
                const item = inv.getItem(i);
                if (item && item.typeId === itemDef.raw) {
                    total += item.amount;
                }
            }

            const craftableBlocks = Math.floor(total / 9);
            if (craftableBlocks > 0) {
                let toRemove = craftableBlocks * 9;
                for (let i = 0; i < inv.size; i++) {
                    if (toRemove <= 0) break;
                    const item = inv.getItem(i);
                    if (!item || item.typeId !== itemDef.raw) continue;

                    if (item.amount <= toRemove) {
                        toRemove -= item.amount;
                        inv.setItem(i, undefined);
                    } else {
                        item.amount -= toRemove;
                        toRemove = 0;
                        inv.setItem(i, item);
                    }
                }
                inv.addItem(new ItemStack(itemDef.block, craftableBlocks));
            }
        }
    }

    /**
     * Converts loose hay bales back into wheat and crafts bread
     */
    static processHayForFood(entity) {
        if (!entity?.isValid) return;
        const inv = entity.getComponent("minecraft:inventory")?.container;
        if (!inv) return;

        for (let i = 0; i < inv.size; i++) {
            const item = inv.getItem(i);
            if (item && item.typeId === "minecraft:hay_block") {
                const count = item.amount;
                inv.setItem(i, undefined);
                inv.addItem(new ItemStack("minecraft:wheat", count * 9));
                break;
            }
        }
    }

    static checkAndCraft(entity) {
        if (!entity?.isValid) return;
        const inv = entity.getComponent("minecraft:inventory")?.container;
        if (!inv) return;

        this.processHayForFood(entity);
        this.autoCompact(entity);

        for (const recipe of this.recipes) {
            if (this.canCraft(inv, recipe)) {
                this.consumeIngredients(inv, recipe);
                inv.addItem(new ItemStack(recipe.result, recipe.count));
            }
        }
    }

    static canCraft(inv, recipe) {
        for (const req of recipe.ingredients) {
            let total = 0;
            for (let i = 0; i < inv.size; i++) {
                const item = inv.getItem(i);
                if (!item) continue;
                if (item.typeId === req.id || item.typeId.endsWith(req.id.replace("minecraft:", ""))) {
                    total += item.amount;
                }
            }
            if (total < req.count) return false;
        }
        return true;
    }

    static consumeIngredients(inv, recipe) {
        for (const req of recipe.ingredients) {
            let remaining = req.count;
            for (let i = 0; i < inv.size; i++) {
                if (remaining <= 0) break;
                const item = inv.getItem(i);
                if (!item) continue;

                if (item.typeId === req.id || item.typeId.endsWith(req.id.replace("minecraft:", ""))) {
                    if (item.amount <= remaining) {
                        remaining -= item.amount;
                        inv.setItem(i, undefined);
                    } else {
                        item.amount -= remaining;
                        remaining = 0;
                        inv.setItem(i, item);
                    }
                }
            }
        }
    }
}

RecipeCrafter.recipes = [];
RecipeCrafter.compactables = [];
