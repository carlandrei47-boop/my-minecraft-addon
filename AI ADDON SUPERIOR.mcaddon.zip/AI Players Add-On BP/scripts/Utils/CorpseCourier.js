import { world, system } from "@minecraft/server";
import V3 from "../Helpers/Vectors/V3.js";

export class CorpseCourier {
    static init() {
        world.afterEvents.entityDie.subscribe((event) => {
            const deadEntity = event.deadEntity;
            if (deadEntity?.typeId !== "minecraft:player") return;

            const loc = deadEntity.location;
            const dimension = deadEntity.dimension;

            CorpseCourier.activeDeathMarkers.set(deadEntity.id, {
                location: new V3(Math.floor(loc.x), Math.floor(loc.y), Math.floor(loc.z)),
                dimension: dimension,
                timestamp: system.currentTick
            });

            CorpseCourier.dispatchCompanionToCorpse(deadEntity.id, dimension, loc);
        });
    }

    static dispatchCompanionToCorpse(playerId, dimension, corpseLoc) {
        const bots = dimension.getEntities({ type: "gm1_sky:aip" });
        if (bots.length === 0) return;

        const companion = bots[0];
        
        system.runTimeout(() => {
            if (!companion.isValid) return;

            const droppedItems = dimension.getEntities({
                location: corpseLoc,
                maxDistance: 8,
                type: "minecraft:item"
            });

            const player = world.getEntity(playerId);
            if (player && player.isValid) {
                const playerLoc = player.location;
                companion.teleport({
                    x: Math.floor(playerLoc.x) + 1,
                    y: Math.floor(playerLoc.y),
                    z: Math.floor(playerLoc.z) + 1
                }, { dimension: player.dimension });

                for (const itemEnt of droppedItems) {
                    if (itemEnt.isValid) {
                        const stack = itemEnt.getComponent("minecraft:item")?.itemStack;
                        if (stack) {
                            player.dimension.spawnItem(stack, player.location);
                            itemEnt.remove();
                        }
                    }
                }
            }
        }, 100);
    }
}

CorpseCourier.activeDeathMarkers = new Map();
