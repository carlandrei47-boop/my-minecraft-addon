import { world } from "@minecraft/server";

export class BaseGuard {
    // 40 blocks squared (40 * 40 = 1600)
    static RADIUS_SQ = 1600;

    static isInsideSafeZone(dimension, targetLocation) {
        if (!targetLocation) return false;

        const homeMarkers = dimension.getEntities({ type: "gamemodeone:home_marker" });

        for (const marker of homeMarkers) {
            const markerLoc = marker.location;
            const dx = targetLocation.x - markerLoc.x;
            const dy = targetLocation.y - markerLoc.y;
            const dz = targetLocation.z - markerLoc.z;

            if ((dx * dx + dy * dy + dz * dz) <= this.RADIUS_SQ) {
                return true;
            }
        }

        return false;
    }
}
