import StateUtils from "../StateUtils";
import AbstractState from "./AbstractState";
class CompositeState extends AbstractState {
    // #region Lifecycle
    /**
     * Enters this state and optionally navigates to a specific substate.
     * @param subaddress - The address of the substate to activate, or uses initialState if not provided
     */ enter(subaddress) {
        super.enter();
        // Set initial subaddress if not provided
        subaddress ?? (subaddress = this.definition.initialState?.identifier);
        if (subaddress) this.setSubaddress(subaddress);
    }
    /**
     * Ticks substates while this composite state is active.
     */ activeTick() {
        this.tickSubstates();
        super.activeTick();
    }
    /**
     * Ticks substates while this composite state is inactive.
     */ inactiveTick() {
        if (this.tickSubstatesWhenInactive) this.tickSubstates();
        super.inactiveTick();
    }
    /**
     * Updates all substates, calling activeTick or inactiveTick based on their state.
     */ tickSubstates() {
        for (const state of Object.values(this.substates)){
            if (this.isActive && state.isActive) state.activeTick();
            else state.inactiveTick();
        }
    }
    /**
     * Exits this state and its current substate if one is active.
     * @param isShutdown - Whether this exit is due to world shutdown
     */ exit(exitType) {
        if (this.currentSubstate) {
            this.currentSubstate.exit(exitType);
            this.currentSubstate = null;
        }
        super.exit(exitType);
    }
    // #endregion
    // #region Substates
    /**
     * Instantiates all substates from the registry.
     */ createSubstates() {
        const registry = this.definition.registry;
        // Initialize state handlers
        const states = {};
        for (const stateClass of registry){
            const state = new stateClass(this.context, this.absoluteAddress);
            states[stateClass.identifier] = state;
        }
        this.substates = states;
        // Cached list of substates for performance, since the map is fixed after construction
        this.substatesList = Object.values(this.substates);
    }
    /**
     * Transitions to a different substate.
     * @param state - The substate instance to transition to, or null to deactivate all substates
     * @returns True if a transition occurred, false if already in the target state
     */ setSubstate(state, lock = false) {
        // Return if this is locked and not being locked
        if (this.isLocked && !lock) return false;
        this.isLocked = lock;
        if (this.currentSubstate) this.currentSubstate.exit();
        this.currentSubstate = state;
        if (!state) return true;
        state.subscribeToSignal("onComplete", ()=>this.onSubstateComplete(state));
        state.subscribeToSignal("onFailure", ()=>this.onSubstateFailure(state));
        state.enter();
        return true;
    }
    /**
     * Gets a substate instance by its class or identifier.
     * @param state - The state class or identifier string
     * @returns The substate instance
     */ getSubstate(state) {
        if (typeof state !== "string") state = state.identifier;
        return this.substates[state];
    }
    /**
     * Gets all substate instances.
     * @returns An array of all substate instances
     */ getSubstates() {
        return this.substatesList;
    }
    /**
     * Checks if any currently active substate below this state matches the class.
     * @param stateClass - The class to search for in this state's subtree
     * @returns True if a matching active substate exists, false otherwise
     */ hasActiveSubstateOfType(stateClass) {
        // Only the current substate can ever be active, so walk the active chain directly
        let substate = this.currentSubstate;
        while(substate){
            if (substate instanceof stateClass && substate.isActive) return true;
            substate = StateUtils.hasCurrentSubstate(substate) ? substate.currentSubstate : null;
        }
        return false;
    }
    /**
     * Handles a signal, first checking this state then propagating to the current substate.
     * @param identifier - The target state identifier
     * @param signal - The signal name
     * @returns True if the signal was handled by this state or a substate
     */ handleSignal(identifier, signal) {
        const handled = super.handleSignal(identifier, signal);
        if (handled) return true;
        if (!this.currentSubstate) return false;
        return this.currentSubstate.handleSignal(identifier, signal);
    }
    /**
     * Gets the address of the deepest active leaf state in the hierarchy.
     * @returns The full address path to the active leaf state, or undefined if no leaf is active
     */ getLeafAddress() {
        let substate = this.currentSubstate;
        while(StateUtils.hasCurrentSubstate(substate))substate = substate.currentSubstate;
        return substate?.absoluteAddress;
    }
    /**
     * Navigates to a specific state using a slash-separated address path.
     * @param subaddress - The relative address path (e.g., "combat/attack")
     * @param lock - Whether to lock this state from automatic transitions
     * @returns True if the address was successfully set, false if the path is invalid
     */ setSubaddress(subaddress, lock = false) {
        const parts = subaddress.split("/");
        const nextIdentifier = parts[0];
        const nextState = this.substates[nextIdentifier];
        if (!nextState) return false;
        const remainingPath = parts.slice(1).join("/");
        const hasRemainingPath = remainingPath && StateUtils.hasSubstates(nextState);
        // Set the substate and lock this state if requested
        this.setSubstate(nextState, lock);
        // If there's a remaining path, recursively set it
        if (hasRemainingPath) return nextState.setSubaddress(remainingPath, lock);
        return true;
    }
    /**
     * Called when a substate successfully completes its execution.
     * @param state - The completed substate
     */ onSubstateComplete(_state) {}
    /**
     * Unlocks all composite substates below this state.
     */ unlock() {
        this.isLocked = false;
        let substate = this.currentSubstate;
        while(substate){
            if (StateUtils.hasSubstates(substate)) substate.isLocked = false;
            if (StateUtils.hasCurrentSubstate(substate)) substate = substate.currentSubstate;
            else break;
        }
    }
    /**
     * Creates a new CompositeState instance and initializes all substates.
     * @param context - The entity context
     */ constructor(context, parentAddress){
        super(context, parentAddress);
        /** The currently active substate, or null if no substate is active */ this.currentSubstate = null;
        /** Indicates whether this state is locked from changing substates */ this.isLocked = false;
        /** Indicates whether to tick inactive substates. Defaults to false. */ this.tickSubstatesWhenInactive = false;
        /** Cached array form of `substates`, since the map is fixed after construction. */ this.substatesList = [];
        this.createSubstates();
    }
}
/**
 * A state that can contain and manage multiple substates.
 *
 * CompositeState allows hierarchical state organization where one substate
 * is active at a time. It handles substate transitions, signal propagation,
 * and address-based navigation.
 *
 * @template Registry - The registry of substate classes
 */ export { CompositeState as default };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkNvbXBvc2l0ZVN0YXRlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBFbnRpdHlDb250ZXh0IGZyb20gXCJTdGF0ZVNrZWxldG9uL0VudGl0eUNvbnRleHRcIjtcclxuaW1wb3J0IFN0YXRlVXRpbHMgZnJvbSBcIi4uL1N0YXRlVXRpbHNcIjtcclxuaW1wb3J0IHtcclxuICAgIENvbW1vblNpZ25hbHMsXHJcbiAgICBDb21wb3NpdGVTdGF0ZURlZmluaXRpb24sXHJcbiAgICBFeGl0VHlwZSxcclxuICAgIFN0YXRlQ2xhc3MsXHJcbiAgICBTdGF0ZURlZmluaXRpb24sXHJcbiAgICBTdGF0ZUlkLFxyXG4gICAgU3RhdGVJbnN0YW5jZU1hcCxcclxuICAgIFN0YXRlUmVnaXN0cnksXHJcbn0gZnJvbSBcIi4uL1R5cGVzXCI7XHJcbmltcG9ydCBBYnN0cmFjdFN0YXRlIGZyb20gXCIuL0Fic3RyYWN0U3RhdGVcIjtcclxuXHJcbi8qKlxyXG4gKiBBIHN0YXRlIHRoYXQgY2FuIGNvbnRhaW4gYW5kIG1hbmFnZSBtdWx0aXBsZSBzdWJzdGF0ZXMuXHJcbiAqXHJcbiAqIENvbXBvc2l0ZVN0YXRlIGFsbG93cyBoaWVyYXJjaGljYWwgc3RhdGUgb3JnYW5pemF0aW9uIHdoZXJlIG9uZSBzdWJzdGF0ZVxyXG4gKiBpcyBhY3RpdmUgYXQgYSB0aW1lLiBJdCBoYW5kbGVzIHN1YnN0YXRlIHRyYW5zaXRpb25zLCBzaWduYWwgcHJvcGFnYXRpb24sXHJcbiAqIGFuZCBhZGRyZXNzLWJhc2VkIG5hdmlnYXRpb24uXHJcbiAqXHJcbiAqIEB0ZW1wbGF0ZSBSZWdpc3RyeSAtIFRoZSByZWdpc3RyeSBvZiBzdWJzdGF0ZSBjbGFzc2VzXHJcbiAqL1xyXG5leHBvcnQgZGVmYXVsdCBhYnN0cmFjdCBjbGFzcyBDb21wb3NpdGVTdGF0ZTxcclxuICAgIFJlZ2lzdHJ5IGV4dGVuZHMgU3RhdGVSZWdpc3RyeSA9IFN0YXRlUmVnaXN0cnksXHJcbiAgICBTaWduYWxzIGV4dGVuZHMgc3RyaW5nID0gQ29tbW9uU2lnbmFscyxcclxuPiBleHRlbmRzIEFic3RyYWN0U3RhdGU8Q29tcG9zaXRlU3RhdGVEZWZpbml0aW9uPFJlZ2lzdHJ5PiwgU2lnbmFscz4ge1xyXG4gICAgLyoqIE1hcCBvZiBhbGwgc3Vic3RhdGUgaW5zdGFuY2VzLCBrZXllZCBieSBpZGVudGlmaWVyICovXHJcbiAgICBwdWJsaWMgc3Vic3RhdGVzOiBTdGF0ZUluc3RhbmNlTWFwPFJlZ2lzdHJ5PjtcclxuXHJcbiAgICAvKiogVGhlIGN1cnJlbnRseSBhY3RpdmUgc3Vic3RhdGUsIG9yIG51bGwgaWYgbm8gc3Vic3RhdGUgaXMgYWN0aXZlICovXHJcbiAgICBwdWJsaWMgY3VycmVudFN1YnN0YXRlOiBJbnN0YW5jZVR5cGU8UmVnaXN0cnlbbnVtYmVyXT4gfCBudWxsID0gbnVsbDtcclxuXHJcbiAgICAvKiogSW5kaWNhdGVzIHdoZXRoZXIgdGhpcyBzdGF0ZSBpcyBsb2NrZWQgZnJvbSBjaGFuZ2luZyBzdWJzdGF0ZXMgKi9cclxuICAgIHB1YmxpYyBpc0xvY2tlZCA9IGZhbHNlO1xyXG5cclxuICAgIC8qKiBJbmRpY2F0ZXMgd2hldGhlciB0byB0aWNrIGluYWN0aXZlIHN1YnN0YXRlcy4gRGVmYXVsdHMgdG8gZmFsc2UuICovXHJcbiAgICBwdWJsaWMgdGlja1N1YnN0YXRlc1doZW5JbmFjdGl2ZSA9IGZhbHNlO1xyXG5cclxuICAgIC8qKlxyXG4gICAgICogQ3JlYXRlcyBhIG5ldyBDb21wb3NpdGVTdGF0ZSBpbnN0YW5jZSBhbmQgaW5pdGlhbGl6ZXMgYWxsIHN1YnN0YXRlcy5cclxuICAgICAqIEBwYXJhbSBjb250ZXh0IC0gVGhlIGVudGl0eSBjb250ZXh0XHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBjb25zdHJ1Y3Rvcihjb250ZXh0OiBFbnRpdHlDb250ZXh0LCBwYXJlbnRBZGRyZXNzPzogc3RyaW5nKSB7XHJcbiAgICAgICAgc3VwZXIoY29udGV4dCwgcGFyZW50QWRkcmVzcyk7XHJcbiAgICAgICAgdGhpcy5jcmVhdGVTdWJzdGF0ZXMoKTtcclxuICAgIH1cclxuXHJcbiAgICAvLyAjcmVnaW9uIExpZmVjeWNsZVxyXG4gICAgLyoqXHJcbiAgICAgKiBFbnRlcnMgdGhpcyBzdGF0ZSBhbmQgb3B0aW9uYWxseSBuYXZpZ2F0ZXMgdG8gYSBzcGVjaWZpYyBzdWJzdGF0ZS5cclxuICAgICAqIEBwYXJhbSBzdWJhZGRyZXNzIC0gVGhlIGFkZHJlc3Mgb2YgdGhlIHN1YnN0YXRlIHRvIGFjdGl2YXRlLCBvciB1c2VzIGluaXRpYWxTdGF0ZSBpZiBub3QgcHJvdmlkZWRcclxuICAgICAqL1xyXG4gICAgcHVibGljIG92ZXJyaWRlIGVudGVyKHN1YmFkZHJlc3M/OiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBzdXBlci5lbnRlcigpO1xyXG5cclxuICAgICAgICAvLyBTZXQgaW5pdGlhbCBzdWJhZGRyZXNzIGlmIG5vdCBwcm92aWRlZFxyXG4gICAgICAgIHN1YmFkZHJlc3MgPz89IHRoaXMuZGVmaW5pdGlvbi5pbml0aWFsU3RhdGU/LmlkZW50aWZpZXI7XHJcbiAgICAgICAgaWYgKHN1YmFkZHJlc3MpIHRoaXMuc2V0U3ViYWRkcmVzcyhzdWJhZGRyZXNzKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFRpY2tzIHN1YnN0YXRlcyB3aGlsZSB0aGlzIGNvbXBvc2l0ZSBzdGF0ZSBpcyBhY3RpdmUuXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBvdmVycmlkZSBhY3RpdmVUaWNrKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMudGlja1N1YnN0YXRlcygpO1xyXG4gICAgICAgIHN1cGVyLmFjdGl2ZVRpY2soKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFRpY2tzIHN1YnN0YXRlcyB3aGlsZSB0aGlzIGNvbXBvc2l0ZSBzdGF0ZSBpcyBpbmFjdGl2ZS5cclxuICAgICAqL1xyXG4gICAgcHVibGljIG92ZXJyaWRlIGluYWN0aXZlVGljaygpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy50aWNrU3Vic3RhdGVzV2hlbkluYWN0aXZlKSB0aGlzLnRpY2tTdWJzdGF0ZXMoKTtcclxuICAgICAgICBzdXBlci5pbmFjdGl2ZVRpY2soKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFVwZGF0ZXMgYWxsIHN1YnN0YXRlcywgY2FsbGluZyBhY3RpdmVUaWNrIG9yIGluYWN0aXZlVGljayBiYXNlZCBvbiB0aGVpciBzdGF0ZS5cclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSB0aWNrU3Vic3RhdGVzKCk6IHZvaWQge1xyXG4gICAgICAgIGZvciAoY29uc3Qgc3RhdGUgb2YgT2JqZWN0LnZhbHVlczxJbnN0YW5jZVR5cGU8UmVnaXN0cnlbbnVtYmVyXT4+KHRoaXMuc3Vic3RhdGVzKSkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5pc0FjdGl2ZSAmJiBzdGF0ZS5pc0FjdGl2ZSkgc3RhdGUuYWN0aXZlVGljaygpO1xyXG4gICAgICAgICAgICBlbHNlIHN0YXRlLmluYWN0aXZlVGljaygpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEV4aXRzIHRoaXMgc3RhdGUgYW5kIGl0cyBjdXJyZW50IHN1YnN0YXRlIGlmIG9uZSBpcyBhY3RpdmUuXHJcbiAgICAgKiBAcGFyYW0gaXNTaHV0ZG93biAtIFdoZXRoZXIgdGhpcyBleGl0IGlzIGR1ZSB0byB3b3JsZCBzaHV0ZG93blxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgb3ZlcnJpZGUgZXhpdChleGl0VHlwZTogRXhpdFR5cGUpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5jdXJyZW50U3Vic3RhdGUpIHtcclxuICAgICAgICAgICAgdGhpcy5jdXJyZW50U3Vic3RhdGUuZXhpdChleGl0VHlwZSk7XHJcbiAgICAgICAgICAgIHRoaXMuY3VycmVudFN1YnN0YXRlID0gbnVsbDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHN1cGVyLmV4aXQoZXhpdFR5cGUpO1xyXG4gICAgfVxyXG4gICAgLy8gI2VuZHJlZ2lvblxyXG5cclxuICAgIC8vICNyZWdpb24gU3Vic3RhdGVzXHJcbiAgICAvKipcclxuICAgICAqIEluc3RhbnRpYXRlcyBhbGwgc3Vic3RhdGVzIGZyb20gdGhlIHJlZ2lzdHJ5LlxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIGNyZWF0ZVN1YnN0YXRlcygpOiB2b2lkIHtcclxuICAgICAgICBjb25zdCByZWdpc3RyeSA9IHRoaXMuZGVmaW5pdGlvbi5yZWdpc3RyeTtcclxuXHJcbiAgICAgICAgLy8gSW5pdGlhbGl6ZSBzdGF0ZSBoYW5kbGVyc1xyXG4gICAgICAgIGNvbnN0IHN0YXRlcyA9IHt9O1xyXG4gICAgICAgIGZvciAoY29uc3Qgc3RhdGVDbGFzcyBvZiByZWdpc3RyeSkge1xyXG4gICAgICAgICAgICBjb25zdCBzdGF0ZSA9IG5ldyBzdGF0ZUNsYXNzKHRoaXMuY29udGV4dCwgdGhpcy5hYnNvbHV0ZUFkZHJlc3MpO1xyXG4gICAgICAgICAgICBzdGF0ZXNbc3RhdGVDbGFzcy5pZGVudGlmaWVyXSA9IHN0YXRlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpcy5zdWJzdGF0ZXMgPSBzdGF0ZXMgYXMgU3RhdGVJbnN0YW5jZU1hcDxSZWdpc3RyeT47XHJcbiAgICAgICAgLy8gQ2FjaGVkIGxpc3Qgb2Ygc3Vic3RhdGVzIGZvciBwZXJmb3JtYW5jZSwgc2luY2UgdGhlIG1hcCBpcyBmaXhlZCBhZnRlciBjb25zdHJ1Y3Rpb25cclxuICAgICAgICB0aGlzLnN1YnN0YXRlc0xpc3QgPSBPYmplY3QudmFsdWVzKHRoaXMuc3Vic3RhdGVzKTtcclxuICAgIH1cclxuXHJcbiAgICAvKiogQ2FjaGVkIGFycmF5IGZvcm0gb2YgYHN1YnN0YXRlc2AsIHNpbmNlIHRoZSBtYXAgaXMgZml4ZWQgYWZ0ZXIgY29uc3RydWN0aW9uLiAqL1xyXG4gICAgcHJpdmF0ZSBzdWJzdGF0ZXNMaXN0OiBJbnN0YW5jZVR5cGU8UmVnaXN0cnlbbnVtYmVyXT5bXSA9IFtdO1xyXG5cclxuICAgIC8qKlxyXG4gICAgICogVHJhbnNpdGlvbnMgdG8gYSBkaWZmZXJlbnQgc3Vic3RhdGUuXHJcbiAgICAgKiBAcGFyYW0gc3RhdGUgLSBUaGUgc3Vic3RhdGUgaW5zdGFuY2UgdG8gdHJhbnNpdGlvbiB0bywgb3IgbnVsbCB0byBkZWFjdGl2YXRlIGFsbCBzdWJzdGF0ZXNcclxuICAgICAqIEByZXR1cm5zIFRydWUgaWYgYSB0cmFuc2l0aW9uIG9jY3VycmVkLCBmYWxzZSBpZiBhbHJlYWR5IGluIHRoZSB0YXJnZXQgc3RhdGVcclxuICAgICAqL1xyXG4gICAgcHVibGljIHNldFN1YnN0YXRlKHN0YXRlOiBJbnN0YW5jZVR5cGU8UmVnaXN0cnlbbnVtYmVyXT4gfCBudWxsLCBsb2NrOiBib29sZWFuID0gZmFsc2UpOiBib29sZWFuIHtcclxuICAgICAgICAvLyBSZXR1cm4gaWYgdGhpcyBpcyBsb2NrZWQgYW5kIG5vdCBiZWluZyBsb2NrZWRcclxuICAgICAgICBpZiAodGhpcy5pc0xvY2tlZCAmJiAhbG9jaykgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgIHRoaXMuaXNMb2NrZWQgPSBsb2NrO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5jdXJyZW50U3Vic3RhdGUpIHRoaXMuY3VycmVudFN1YnN0YXRlLmV4aXQoKTtcclxuXHJcbiAgICAgICAgdGhpcy5jdXJyZW50U3Vic3RhdGUgPSBzdGF0ZTtcclxuICAgICAgICBpZiAoIXN0YXRlKSByZXR1cm4gdHJ1ZTtcclxuXHJcbiAgICAgICAgc3RhdGUuc3Vic2NyaWJlVG9TaWduYWwoXCJvbkNvbXBsZXRlXCIsICgpID0+IHRoaXMub25TdWJzdGF0ZUNvbXBsZXRlKHN0YXRlKSk7XHJcbiAgICAgICAgc3RhdGUuc3Vic2NyaWJlVG9TaWduYWwoXCJvbkZhaWx1cmVcIiwgKCkgPT4gdGhpcy5vblN1YnN0YXRlRmFpbHVyZShzdGF0ZSkpO1xyXG4gICAgICAgIHN0YXRlLmVudGVyKCk7XHJcblxyXG4gICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogR2V0cyBhIHN1YnN0YXRlIGluc3RhbmNlIGJ5IGl0cyBjbGFzcyBvciBpZGVudGlmaWVyLlxyXG4gICAgICogQHBhcmFtIHN0YXRlIC0gVGhlIHN0YXRlIGNsYXNzIG9yIGlkZW50aWZpZXIgc3RyaW5nXHJcbiAgICAgKiBAcmV0dXJucyBUaGUgc3Vic3RhdGUgaW5zdGFuY2VcclxuICAgICAqL1xyXG4gICAgcHVibGljIGdldFN1YnN0YXRlPEsgZXh0ZW5kcyBSZWdpc3RyeVtudW1iZXJdPihzdGF0ZTogSyB8IFN0YXRlSWQ8UmVnaXN0cnk+KTogSW5zdGFuY2VUeXBlPEs+IHtcclxuICAgICAgICBpZiAodHlwZW9mIHN0YXRlICE9PSBcInN0cmluZ1wiKSBzdGF0ZSA9IHN0YXRlLmlkZW50aWZpZXI7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuc3Vic3RhdGVzW3N0YXRlXSBhcyBJbnN0YW5jZVR5cGU8Sz47XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBHZXRzIGFsbCBzdWJzdGF0ZSBpbnN0YW5jZXMuXHJcbiAgICAgKiBAcmV0dXJucyBBbiBhcnJheSBvZiBhbGwgc3Vic3RhdGUgaW5zdGFuY2VzXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBnZXRTdWJzdGF0ZXMoKTogSW5zdGFuY2VUeXBlPFJlZ2lzdHJ5W251bWJlcl0+W10ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLnN1YnN0YXRlc0xpc3Q7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBDaGVja3MgaWYgYW55IGN1cnJlbnRseSBhY3RpdmUgc3Vic3RhdGUgYmVsb3cgdGhpcyBzdGF0ZSBtYXRjaGVzIHRoZSBjbGFzcy5cclxuICAgICAqIEBwYXJhbSBzdGF0ZUNsYXNzIC0gVGhlIGNsYXNzIHRvIHNlYXJjaCBmb3IgaW4gdGhpcyBzdGF0ZSdzIHN1YnRyZWVcclxuICAgICAqIEByZXR1cm5zIFRydWUgaWYgYSBtYXRjaGluZyBhY3RpdmUgc3Vic3RhdGUgZXhpc3RzLCBmYWxzZSBvdGhlcndpc2VcclxuICAgICAqL1xyXG4gICAgcHVibGljIGhhc0FjdGl2ZVN1YnN0YXRlT2ZUeXBlPFMgZXh0ZW5kcyBBYnN0cmFjdFN0YXRlPihzdGF0ZUNsYXNzOiBTdGF0ZUNsYXNzPFM+KTogYm9vbGVhbiB7XHJcbiAgICAgICAgLy8gT25seSB0aGUgY3VycmVudCBzdWJzdGF0ZSBjYW4gZXZlciBiZSBhY3RpdmUsIHNvIHdhbGsgdGhlIGFjdGl2ZSBjaGFpbiBkaXJlY3RseVxyXG4gICAgICAgIGxldCBzdWJzdGF0ZTogQWJzdHJhY3RTdGF0ZSB8IG51bGwgPSB0aGlzLmN1cnJlbnRTdWJzdGF0ZTtcclxuICAgICAgICB3aGlsZSAoc3Vic3RhdGUpIHtcclxuICAgICAgICAgICAgaWYgKHN1YnN0YXRlIGluc3RhbmNlb2Ygc3RhdGVDbGFzcyAmJiBzdWJzdGF0ZS5pc0FjdGl2ZSkgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgICAgIHN1YnN0YXRlID0gU3RhdGVVdGlscy5oYXNDdXJyZW50U3Vic3RhdGUoc3Vic3RhdGUpID8gc3Vic3RhdGUuY3VycmVudFN1YnN0YXRlIDogbnVsbDtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogSGFuZGxlcyBhIHNpZ25hbCwgZmlyc3QgY2hlY2tpbmcgdGhpcyBzdGF0ZSB0aGVuIHByb3BhZ2F0aW5nIHRvIHRoZSBjdXJyZW50IHN1YnN0YXRlLlxyXG4gICAgICogQHBhcmFtIGlkZW50aWZpZXIgLSBUaGUgdGFyZ2V0IHN0YXRlIGlkZW50aWZpZXJcclxuICAgICAqIEBwYXJhbSBzaWduYWwgLSBUaGUgc2lnbmFsIG5hbWVcclxuICAgICAqIEByZXR1cm5zIFRydWUgaWYgdGhlIHNpZ25hbCB3YXMgaGFuZGxlZCBieSB0aGlzIHN0YXRlIG9yIGEgc3Vic3RhdGVcclxuICAgICAqL1xyXG4gICAgcHVibGljIG92ZXJyaWRlIGhhbmRsZVNpZ25hbChpZGVudGlmaWVyOiBTdGF0ZUlkPFJlZ2lzdHJ5Piwgc2lnbmFsOiBrZXlvZiB0eXBlb2YgdGhpcy5zaWduYWxzKTogYm9vbGVhbiB7XHJcbiAgICAgICAgY29uc3QgaGFuZGxlZCA9IHN1cGVyLmhhbmRsZVNpZ25hbChpZGVudGlmaWVyLCBzaWduYWwpO1xyXG4gICAgICAgIGlmIChoYW5kbGVkKSByZXR1cm4gdHJ1ZTtcclxuXHJcbiAgICAgICAgaWYgKCF0aGlzLmN1cnJlbnRTdWJzdGF0ZSkgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgIHJldHVybiAodGhpcy5jdXJyZW50U3Vic3RhdGUgYXMgQWJzdHJhY3RTdGF0ZTxTdGF0ZURlZmluaXRpb24sIFNpZ25hbHM+KS5oYW5kbGVTaWduYWwoaWRlbnRpZmllciwgc2lnbmFsKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEdldHMgdGhlIGFkZHJlc3Mgb2YgdGhlIGRlZXBlc3QgYWN0aXZlIGxlYWYgc3RhdGUgaW4gdGhlIGhpZXJhcmNoeS5cclxuICAgICAqIEByZXR1cm5zIFRoZSBmdWxsIGFkZHJlc3MgcGF0aCB0byB0aGUgYWN0aXZlIGxlYWYgc3RhdGUsIG9yIHVuZGVmaW5lZCBpZiBubyBsZWFmIGlzIGFjdGl2ZVxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgZ2V0TGVhZkFkZHJlc3MoKTogc3RyaW5nIHwgdW5kZWZpbmVkIHtcclxuICAgICAgICBsZXQgc3Vic3RhdGU6IEFic3RyYWN0U3RhdGUgfCBudWxsID0gdGhpcy5jdXJyZW50U3Vic3RhdGU7XHJcbiAgICAgICAgd2hpbGUgKFN0YXRlVXRpbHMuaGFzQ3VycmVudFN1YnN0YXRlKHN1YnN0YXRlKSkgc3Vic3RhdGUgPSBzdWJzdGF0ZS5jdXJyZW50U3Vic3RhdGU7XHJcbiAgICAgICAgcmV0dXJuIHN1YnN0YXRlPy5hYnNvbHV0ZUFkZHJlc3M7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBOYXZpZ2F0ZXMgdG8gYSBzcGVjaWZpYyBzdGF0ZSB1c2luZyBhIHNsYXNoLXNlcGFyYXRlZCBhZGRyZXNzIHBhdGguXHJcbiAgICAgKiBAcGFyYW0gc3ViYWRkcmVzcyAtIFRoZSByZWxhdGl2ZSBhZGRyZXNzIHBhdGggKGUuZy4sIFwiY29tYmF0L2F0dGFja1wiKVxyXG4gICAgICogQHBhcmFtIGxvY2sgLSBXaGV0aGVyIHRvIGxvY2sgdGhpcyBzdGF0ZSBmcm9tIGF1dG9tYXRpYyB0cmFuc2l0aW9uc1xyXG4gICAgICogQHJldHVybnMgVHJ1ZSBpZiB0aGUgYWRkcmVzcyB3YXMgc3VjY2Vzc2Z1bGx5IHNldCwgZmFsc2UgaWYgdGhlIHBhdGggaXMgaW52YWxpZFxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgc2V0U3ViYWRkcmVzcyhzdWJhZGRyZXNzOiBzdHJpbmcsIGxvY2s6IGJvb2xlYW4gPSBmYWxzZSk6IGJvb2xlYW4ge1xyXG4gICAgICAgIGNvbnN0IHBhcnRzID0gc3ViYWRkcmVzcy5zcGxpdChcIi9cIik7XHJcblxyXG4gICAgICAgIGNvbnN0IG5leHRJZGVudGlmaWVyID0gcGFydHNbMF07XHJcbiAgICAgICAgY29uc3QgbmV4dFN0YXRlID0gdGhpcy5zdWJzdGF0ZXNbbmV4dElkZW50aWZpZXJdO1xyXG4gICAgICAgIGlmICghbmV4dFN0YXRlKSByZXR1cm4gZmFsc2U7XHJcblxyXG4gICAgICAgIGNvbnN0IHJlbWFpbmluZ1BhdGggPSBwYXJ0cy5zbGljZSgxKS5qb2luKFwiL1wiKTtcclxuICAgICAgICBjb25zdCBoYXNSZW1haW5pbmdQYXRoID0gcmVtYWluaW5nUGF0aCAmJiBTdGF0ZVV0aWxzLmhhc1N1YnN0YXRlcyhuZXh0U3RhdGUpO1xyXG5cclxuICAgICAgICAvLyBTZXQgdGhlIHN1YnN0YXRlIGFuZCBsb2NrIHRoaXMgc3RhdGUgaWYgcmVxdWVzdGVkXHJcbiAgICAgICAgdGhpcy5zZXRTdWJzdGF0ZShuZXh0U3RhdGUsIGxvY2spO1xyXG5cclxuICAgICAgICAvLyBJZiB0aGVyZSdzIGEgcmVtYWluaW5nIHBhdGgsIHJlY3Vyc2l2ZWx5IHNldCBpdFxyXG4gICAgICAgIGlmIChoYXNSZW1haW5pbmdQYXRoKSByZXR1cm4gbmV4dFN0YXRlLnNldFN1YmFkZHJlc3MocmVtYWluaW5nUGF0aCwgbG9jayk7XHJcblxyXG4gICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogQ2FsbGVkIHdoZW4gYSBzdWJzdGF0ZSBzdWNjZXNzZnVsbHkgY29tcGxldGVzIGl0cyBleGVjdXRpb24uXHJcbiAgICAgKiBAcGFyYW0gc3RhdGUgLSBUaGUgY29tcGxldGVkIHN1YnN0YXRlXHJcbiAgICAgKi9cclxuICAgIHByb3RlY3RlZCBvblN1YnN0YXRlQ29tcGxldGUoX3N0YXRlOiBBYnN0cmFjdFN0YXRlKTogdm9pZCB7fVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogQ2FsbGVkIHdoZW4gYSBzdWJzdGF0ZSBmYWlscyB0byBjb21wbGV0ZSBpdHMgZXhlY3V0aW9uLlxyXG4gICAgICogTXVzdCBiZSBpbXBsZW1lbnRlZCBhdCBtaW5pbXVtIHRvIHByb3BhZ2F0ZSBmYWlsdXJlIHNpZ25hbHMgdXAgdGhlIGhpZXJhcmNoeS5cclxuICAgICAqIEBwYXJhbSBfc3RhdGUgLSBUaGUgZmFpbGVkIHN1YnN0YXRlXHJcbiAgICAgKi9cclxuICAgIHByb3RlY3RlZCBhYnN0cmFjdCBvblN1YnN0YXRlRmFpbHVyZShfc3RhdGU6IEFic3RyYWN0U3RhdGUpOiB2b2lkO1xyXG5cclxuICAgIC8qKlxyXG4gICAgICogVW5sb2NrcyBhbGwgY29tcG9zaXRlIHN1YnN0YXRlcyBiZWxvdyB0aGlzIHN0YXRlLlxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgdW5sb2NrKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuaXNMb2NrZWQgPSBmYWxzZTtcclxuXHJcbiAgICAgICAgbGV0IHN1YnN0YXRlOiBBYnN0cmFjdFN0YXRlIHwgbnVsbCA9IHRoaXMuY3VycmVudFN1YnN0YXRlO1xyXG5cclxuICAgICAgICB3aGlsZSAoc3Vic3RhdGUpIHtcclxuICAgICAgICAgICAgaWYgKFN0YXRlVXRpbHMuaGFzU3Vic3RhdGVzKHN1YnN0YXRlKSkgc3Vic3RhdGUuaXNMb2NrZWQgPSBmYWxzZTtcclxuICAgICAgICAgICAgaWYgKFN0YXRlVXRpbHMuaGFzQ3VycmVudFN1YnN0YXRlKHN1YnN0YXRlKSkgc3Vic3RhdGUgPSBzdWJzdGF0ZS5jdXJyZW50U3Vic3RhdGU7XHJcbiAgICAgICAgICAgIGVsc2UgYnJlYWs7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgLy8gI2VuZHJlZ2lvblxyXG59XHJcbiJdLCJuYW1lcyI6WyJTdGF0ZVV0aWxzIiwiQWJzdHJhY3RTdGF0ZSIsIkNvbXBvc2l0ZVN0YXRlIiwiZW50ZXIiLCJzdWJhZGRyZXNzIiwiZGVmaW5pdGlvbiIsImluaXRpYWxTdGF0ZSIsImlkZW50aWZpZXIiLCJzZXRTdWJhZGRyZXNzIiwiYWN0aXZlVGljayIsInRpY2tTdWJzdGF0ZXMiLCJpbmFjdGl2ZVRpY2siLCJ0aWNrU3Vic3RhdGVzV2hlbkluYWN0aXZlIiwic3RhdGUiLCJPYmplY3QiLCJ2YWx1ZXMiLCJzdWJzdGF0ZXMiLCJpc0FjdGl2ZSIsImV4aXQiLCJleGl0VHlwZSIsImN1cnJlbnRTdWJzdGF0ZSIsImNyZWF0ZVN1YnN0YXRlcyIsInJlZ2lzdHJ5Iiwic3RhdGVzIiwic3RhdGVDbGFzcyIsImNvbnRleHQiLCJhYnNvbHV0ZUFkZHJlc3MiLCJzdWJzdGF0ZXNMaXN0Iiwic2V0U3Vic3RhdGUiLCJsb2NrIiwiaXNMb2NrZWQiLCJzdWJzY3JpYmVUb1NpZ25hbCIsIm9uU3Vic3RhdGVDb21wbGV0ZSIsIm9uU3Vic3RhdGVGYWlsdXJlIiwiZ2V0U3Vic3RhdGUiLCJnZXRTdWJzdGF0ZXMiLCJoYXNBY3RpdmVTdWJzdGF0ZU9mVHlwZSIsInN1YnN0YXRlIiwiaGFzQ3VycmVudFN1YnN0YXRlIiwiaGFuZGxlU2lnbmFsIiwic2lnbmFsIiwiaGFuZGxlZCIsImdldExlYWZBZGRyZXNzIiwicGFydHMiLCJzcGxpdCIsIm5leHRJZGVudGlmaWVyIiwibmV4dFN0YXRlIiwicmVtYWluaW5nUGF0aCIsInNsaWNlIiwiam9pbiIsImhhc1JlbWFpbmluZ1BhdGgiLCJoYXNTdWJzdGF0ZXMiLCJfc3RhdGUiLCJ1bmxvY2siLCJwYXJlbnRBZGRyZXNzIl0sIm1hcHBpbmdzIjoiQUFDQSxPQUFPQSxnQkFBZ0IsZ0JBQWdCO0FBV3ZDLE9BQU9DLG1CQUFtQixrQkFBa0I7QUFXN0IsTUFBZUMsdUJBR3BCRDtJQXNCTixvQkFBb0I7SUFDcEI7OztLQUdDLEdBQ0QsQUFBZ0JFLE1BQU1DLFVBQW1CLEVBQVE7UUFDN0MsS0FBSyxDQUFDRDtRQUVOLHlDQUF5QztRQUN6Q0MsZUFBQUEsYUFBZSxJQUFJLENBQUNDLFVBQVUsQ0FBQ0MsWUFBWSxFQUFFQztRQUM3QyxJQUFJSCxZQUFZLElBQUksQ0FBQ0ksYUFBYSxDQUFDSjtJQUN2QztJQUVBOztLQUVDLEdBQ0QsQUFBZ0JLLGFBQW1CO1FBQy9CLElBQUksQ0FBQ0MsYUFBYTtRQUNsQixLQUFLLENBQUNEO0lBQ1Y7SUFFQTs7S0FFQyxHQUNELEFBQWdCRSxlQUFxQjtRQUNqQyxJQUFJLElBQUksQ0FBQ0MseUJBQXlCLEVBQUUsSUFBSSxDQUFDRixhQUFhO1FBQ3RELEtBQUssQ0FBQ0M7SUFDVjtJQUVBOztLQUVDLEdBQ0QsQUFBUUQsZ0JBQXNCO1FBQzFCLEtBQUssTUFBTUcsU0FBU0MsT0FBT0MsTUFBTSxDQUFpQyxJQUFJLENBQUNDLFNBQVMsRUFBRztZQUMvRSxJQUFJLElBQUksQ0FBQ0MsUUFBUSxJQUFJSixNQUFNSSxRQUFRLEVBQUVKLE1BQU1KLFVBQVU7aUJBQ2hESSxNQUFNRixZQUFZO1FBQzNCO0lBQ0o7SUFFQTs7O0tBR0MsR0FDRCxBQUFnQk8sS0FBS0MsUUFBa0IsRUFBUTtRQUMzQyxJQUFJLElBQUksQ0FBQ0MsZUFBZSxFQUFFO1lBQ3RCLElBQUksQ0FBQ0EsZUFBZSxDQUFDRixJQUFJLENBQUNDO1lBQzFCLElBQUksQ0FBQ0MsZUFBZSxHQUFHO1FBQzNCO1FBRUEsS0FBSyxDQUFDRixLQUFLQztJQUNmO0lBQ0EsYUFBYTtJQUViLG9CQUFvQjtJQUNwQjs7S0FFQyxHQUNELEFBQVFFLGtCQUF3QjtRQUM1QixNQUFNQyxXQUFXLElBQUksQ0FBQ2pCLFVBQVUsQ0FBQ2lCLFFBQVE7UUFFekMsNEJBQTRCO1FBQzVCLE1BQU1DLFNBQVMsQ0FBQztRQUNoQixLQUFLLE1BQU1DLGNBQWNGLFNBQVU7WUFDL0IsTUFBTVQsUUFBUSxJQUFJVyxXQUFXLElBQUksQ0FBQ0MsT0FBTyxFQUFFLElBQUksQ0FBQ0MsZUFBZTtZQUMvREgsTUFBTSxDQUFDQyxXQUFXakIsVUFBVSxDQUFDLEdBQUdNO1FBQ3BDO1FBRUEsSUFBSSxDQUFDRyxTQUFTLEdBQUdPO1FBQ2pCLHNGQUFzRjtRQUN0RixJQUFJLENBQUNJLGFBQWEsR0FBR2IsT0FBT0MsTUFBTSxDQUFDLElBQUksQ0FBQ0MsU0FBUztJQUNyRDtJQUtBOzs7O0tBSUMsR0FDRCxBQUFPWSxZQUFZZixLQUE0QyxFQUFFZ0IsT0FBZ0IsS0FBSyxFQUFXO1FBQzdGLGdEQUFnRDtRQUNoRCxJQUFJLElBQUksQ0FBQ0MsUUFBUSxJQUFJLENBQUNELE1BQU0sT0FBTztRQUNuQyxJQUFJLENBQUNDLFFBQVEsR0FBR0Q7UUFFaEIsSUFBSSxJQUFJLENBQUNULGVBQWUsRUFBRSxJQUFJLENBQUNBLGVBQWUsQ0FBQ0YsSUFBSTtRQUVuRCxJQUFJLENBQUNFLGVBQWUsR0FBR1A7UUFDdkIsSUFBSSxDQUFDQSxPQUFPLE9BQU87UUFFbkJBLE1BQU1rQixpQkFBaUIsQ0FBQyxjQUFjLElBQU0sSUFBSSxDQUFDQyxrQkFBa0IsQ0FBQ25CO1FBQ3BFQSxNQUFNa0IsaUJBQWlCLENBQUMsYUFBYSxJQUFNLElBQUksQ0FBQ0UsaUJBQWlCLENBQUNwQjtRQUNsRUEsTUFBTVYsS0FBSztRQUVYLE9BQU87SUFDWDtJQUVBOzs7O0tBSUMsR0FDRCxBQUFPK0IsWUFBd0NyQixLQUE0QixFQUFtQjtRQUMxRixJQUFJLE9BQU9BLFVBQVUsVUFBVUEsUUFBUUEsTUFBTU4sVUFBVTtRQUN2RCxPQUFPLElBQUksQ0FBQ1MsU0FBUyxDQUFDSCxNQUFNO0lBQ2hDO0lBRUE7OztLQUdDLEdBQ0QsQUFBT3NCLGVBQWlEO1FBQ3BELE9BQU8sSUFBSSxDQUFDUixhQUFhO0lBQzdCO0lBRUE7Ozs7S0FJQyxHQUNELEFBQU9TLHdCQUFpRFosVUFBeUIsRUFBVztRQUN4RixrRkFBa0Y7UUFDbEYsSUFBSWEsV0FBaUMsSUFBSSxDQUFDakIsZUFBZTtRQUN6RCxNQUFPaUIsU0FBVTtZQUNiLElBQUlBLG9CQUFvQmIsY0FBY2EsU0FBU3BCLFFBQVEsRUFBRSxPQUFPO1lBQ2hFb0IsV0FBV3JDLFdBQVdzQyxrQkFBa0IsQ0FBQ0QsWUFBWUEsU0FBU2pCLGVBQWUsR0FBRztRQUNwRjtRQUNBLE9BQU87SUFDWDtJQUVBOzs7OztLQUtDLEdBQ0QsQUFBZ0JtQixhQUFhaEMsVUFBNkIsRUFBRWlDLE1BQWlDLEVBQVc7UUFDcEcsTUFBTUMsVUFBVSxLQUFLLENBQUNGLGFBQWFoQyxZQUFZaUM7UUFDL0MsSUFBSUMsU0FBUyxPQUFPO1FBRXBCLElBQUksQ0FBQyxJQUFJLENBQUNyQixlQUFlLEVBQUUsT0FBTztRQUNsQyxPQUFPLEFBQUMsSUFBSSxDQUFDQSxlQUFlLENBQTZDbUIsWUFBWSxDQUFDaEMsWUFBWWlDO0lBQ3RHO0lBRUE7OztLQUdDLEdBQ0QsQUFBT0UsaUJBQXFDO1FBQ3hDLElBQUlMLFdBQWlDLElBQUksQ0FBQ2pCLGVBQWU7UUFDekQsTUFBT3BCLFdBQVdzQyxrQkFBa0IsQ0FBQ0QsVUFBV0EsV0FBV0EsU0FBU2pCLGVBQWU7UUFDbkYsT0FBT2lCLFVBQVVYO0lBQ3JCO0lBRUE7Ozs7O0tBS0MsR0FDRCxBQUFPbEIsY0FBY0osVUFBa0IsRUFBRXlCLE9BQWdCLEtBQUssRUFBVztRQUNyRSxNQUFNYyxRQUFRdkMsV0FBV3dDLEtBQUssQ0FBQztRQUUvQixNQUFNQyxpQkFBaUJGLEtBQUssQ0FBQyxFQUFFO1FBQy9CLE1BQU1HLFlBQVksSUFBSSxDQUFDOUIsU0FBUyxDQUFDNkIsZUFBZTtRQUNoRCxJQUFJLENBQUNDLFdBQVcsT0FBTztRQUV2QixNQUFNQyxnQkFBZ0JKLE1BQU1LLEtBQUssQ0FBQyxHQUFHQyxJQUFJLENBQUM7UUFDMUMsTUFBTUMsbUJBQW1CSCxpQkFBaUIvQyxXQUFXbUQsWUFBWSxDQUFDTDtRQUVsRSxvREFBb0Q7UUFDcEQsSUFBSSxDQUFDbEIsV0FBVyxDQUFDa0IsV0FBV2pCO1FBRTVCLGtEQUFrRDtRQUNsRCxJQUFJcUIsa0JBQWtCLE9BQU9KLFVBQVV0QyxhQUFhLENBQUN1QyxlQUFlbEI7UUFFcEUsT0FBTztJQUNYO0lBRUE7OztLQUdDLEdBQ0QsQUFBVUcsbUJBQW1Cb0IsTUFBcUIsRUFBUSxDQUFDO0lBUzNEOztLQUVDLEdBQ0QsQUFBT0MsU0FBZTtRQUNsQixJQUFJLENBQUN2QixRQUFRLEdBQUc7UUFFaEIsSUFBSU8sV0FBaUMsSUFBSSxDQUFDakIsZUFBZTtRQUV6RCxNQUFPaUIsU0FBVTtZQUNiLElBQUlyQyxXQUFXbUQsWUFBWSxDQUFDZCxXQUFXQSxTQUFTUCxRQUFRLEdBQUc7WUFDM0QsSUFBSTlCLFdBQVdzQyxrQkFBa0IsQ0FBQ0QsV0FBV0EsV0FBV0EsU0FBU2pCLGVBQWU7aUJBQzNFO1FBQ1Q7SUFDSjtJQXROQTs7O0tBR0MsR0FDRCxZQUFtQkssT0FBc0IsRUFBRTZCLGFBQXNCLENBQUU7UUFDL0QsS0FBSyxDQUFDN0IsU0FBUzZCO1FBZG5CLG9FQUFvRSxRQUM3RGxDLGtCQUF5RDtRQUVoRSxtRUFBbUUsUUFDNURVLFdBQVc7UUFFbEIscUVBQXFFLFFBQzlEbEIsNEJBQTRCO1FBbUZuQyxpRkFBaUYsUUFDekVlLGdCQUFrRCxFQUFFO1FBNUV4RCxJQUFJLENBQUNOLGVBQWU7SUFDeEI7QUFpTko7QUFqUEE7Ozs7Ozs7O0NBUUMsR0FDRCxTQUE4Qm5CLDRCQXdPN0IifQ==