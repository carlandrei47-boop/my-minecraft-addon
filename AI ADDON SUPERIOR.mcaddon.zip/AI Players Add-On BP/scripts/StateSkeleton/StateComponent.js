import AbstractMobComponent from "MobComponents/AbstractMobComponent";
import { ExitType } from "./Types";
class StateComponent extends AbstractMobComponent {
    /**
     * Called after onEnter() returns for a successfully entered state.
     * Override in subclasses to track enter-depth or perform post-entry work.
     */ onStateEntered() {}
    /**
     * Processes a single tick for the state machine, updating context and active states.
     */ process() {
        this.context.onTick();
        this.root.activeTick();
    }
    /**
     * Handles data-driven entity trigger events
     * @param event - The trigger event
     */ onTrigger(event) {
        const parts = event.eventId.split(".");
        const [identifier, method, ...leftover] = parts;
        const data = leftover.join(".");
        switch(method){
            case "signal":
                this.root.handleSignal(identifier, data);
                break;
        }
    }
    /** Handles entity removal events */ onEntityRemoved() {
        this.root.exit(ExitType.Remove);
    }
    /**
     * Handles world shutdown by persisting the current state and cleaning up.
     */ onShutdown() {
        this.writeAddressToStore();
        this.root.exit(ExitType.Shutdown);
    }
    /** Handles state change events */ onStateChange(newAddress) {
        this.currentAddress = newAddress;
    }
    /**
     * Persists the current leaf state address to entity dynamic properties.
     */ writeAddressToStore() {
        const address = this.root.getLeafAddress();
        this.entity.setDynamicProperty(StateComponent.ADDRESS_KEY, address);
    }
    /**
     * Reads the previously persisted state address from entity dynamic properties.
     * @returns The saved state address, or undefined if none exists
     */ readAddressFromStore() {
        return this.entity.getDynamicProperty(StateComponent.ADDRESS_KEY);
    }
    /** Registers a state instance with the component
     * @param state - The state instance to register
     */ registerState(state) {
        var _this_stateMap, _state_identifier;
        (_this_stateMap = this.stateMap)[_state_identifier = state.identifier] ?? (_this_stateMap[_state_identifier] = []);
        this.stateMap[state.identifier].push(state);
    }
    /**
     * Finds all instances of a state class registered in this component.
     * @param stateClass - The class to search for
     * @param isActiveOnly - Whether to only include active states in the results
     * @returns An array of matching state instances
     */ findAll(stateClass, isActiveOnly = false) {
        const states = this.stateMap[stateClass.identifier] ?? [];
        return isActiveOnly ? states.filter((s)=>s.isActive) : states;
    }
    /**
     * Finds the first instance of a state class registered in this component.
     * @param stateClass - The class to search for
     * @param isActiveOnly - Whether to only consider active states
     * @returns The first matching state instance, or null if none found
     */ findFirst(stateClass, isActiveOnly = false) {
        const states = this.stateMap[stateClass.identifier] ?? [];
        return (isActiveOnly ? states.find((s)=>s.isActive) : states[0]) ?? null;
    }
    /** Checks if any active state of the specified class exists in this component.
     * @param stateClass - The class to check for
     * @returns True if an active state of the class exists, false otherwise
     */ hasActiveState(stateClass) {
        const states = this.stateMap[stateClass.identifier] ?? [];
        return states.some((s)=>s.isActive);
    }
    /**
     * Creates a new StateComponent instance.
     * @param entity - The entity this component is attached to
     * @param rootStateClass - The root composite state class
     * @param context - The context class to instantiate
     */ constructor(entity, rootStateClass, context){
        super(entity, 1);
        /** The current leaf state address, or null if no active state */ this.currentAddress = null;
        this.stateMap = {};
        /**
     * When true, AbstractState.enter() will skip calling onEnter and immediately
     * undo the activation. Set by subclasses to abort a cascade mid-flight.
     */ this.isEnterBlocked = false;
        this.context = new context(entity, this);
        this.root = new rootStateClass(this.context);
        const address = this.readAddressFromStore();
        const strippedAddress = address?.split("/").splice(1).join("/");
        this.root.enter(strippedAddress);
        this.onWorldEvent("WorldAfterEvents", "dataDrivenEntityTrigger", this.onTrigger.bind(this), {
            entities: [
                this.entity
            ]
        });
        this.onWorldEvent("SystemBeforeEvents", "shutdown", this.onShutdown.bind(this));
        this.onWorldEvent("WorldAfterEvents", "entityRemove", this.onEntityRemoved.bind(this), {
            entities: [
                this.entity
            ]
        });
    }
}
StateComponent.ADDRESS_KEY = "state_skeleton:address";
/**
 * Component that manages a hierarchical state machine for an entity.
 *
 * StateComponent integrates a state machine with an entity, handling state persistence,
 * signal processing, and tick updates. It automatically saves and restores state on shutdown.
 *
 * @template Context - The entity context class type
 */ export { StateComponent as default };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIlN0YXRlQ29tcG9uZW50LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IERhdGFEcml2ZW5FbnRpdHlUcmlnZ2VyQWZ0ZXJFdmVudCwgRW50aXR5IH0gZnJvbSBcIkBtaW5lY3JhZnQvc2VydmVyXCI7XHJcbmltcG9ydCBBYnN0cmFjdE1vYkNvbXBvbmVudCBmcm9tIFwiTW9iQ29tcG9uZW50cy9BYnN0cmFjdE1vYkNvbXBvbmVudFwiO1xyXG5pbXBvcnQgQWJzdHJhY3RTdGF0ZSBmcm9tIFwiLi9TdGF0ZXMvQWJzdHJhY3RTdGF0ZVwiO1xyXG5pbXBvcnQgQ29tcG9zaXRlU3RhdGUgZnJvbSBcIi4vU3RhdGVzL0NvbXBvc2l0ZVN0YXRlXCI7XHJcbmltcG9ydCB7IENvbW1vblNpZ25hbHMsIENvbmNyZXRlU3RhdGVDbGFzcywgRW50aXR5Q29udGV4dENsYXNzLCBFeGl0VHlwZSwgU3RhdGVDbGFzcyB9IGZyb20gXCIuL1R5cGVzXCI7XHJcblxyXG4vKipcclxuICogQ29tcG9uZW50IHRoYXQgbWFuYWdlcyBhIGhpZXJhcmNoaWNhbCBzdGF0ZSBtYWNoaW5lIGZvciBhbiBlbnRpdHkuXHJcbiAqXHJcbiAqIFN0YXRlQ29tcG9uZW50IGludGVncmF0ZXMgYSBzdGF0ZSBtYWNoaW5lIHdpdGggYW4gZW50aXR5LCBoYW5kbGluZyBzdGF0ZSBwZXJzaXN0ZW5jZSxcclxuICogc2lnbmFsIHByb2Nlc3NpbmcsIGFuZCB0aWNrIHVwZGF0ZXMuIEl0IGF1dG9tYXRpY2FsbHkgc2F2ZXMgYW5kIHJlc3RvcmVzIHN0YXRlIG9uIHNodXRkb3duLlxyXG4gKlxyXG4gKiBAdGVtcGxhdGUgQ29udGV4dCAtIFRoZSBlbnRpdHkgY29udGV4dCBjbGFzcyB0eXBlXHJcbiAqL1xyXG5leHBvcnQgZGVmYXVsdCBhYnN0cmFjdCBjbGFzcyBTdGF0ZUNvbXBvbmVudDxDb250ZXh0IGV4dGVuZHMgRW50aXR5Q29udGV4dENsYXNzID0gRW50aXR5Q29udGV4dENsYXNzPiBleHRlbmRzIEFic3RyYWN0TW9iQ29tcG9uZW50IHtcclxuICAgIHByaXZhdGUgc3RhdGljIHJlYWRvbmx5IEFERFJFU1NfS0VZID0gXCJzdGF0ZV9za2VsZXRvbjphZGRyZXNzXCI7XHJcblxyXG4gICAgLyoqIFRoZSByb290IGNvbXBvc2l0ZSBzdGF0ZSBvZiB0aGUgc3RhdGUgbWFjaGluZSAqL1xyXG4gICAgcHVibGljIHJlYWRvbmx5IHJvb3Q6IENvbXBvc2l0ZVN0YXRlO1xyXG5cclxuICAgIC8qKiBUaGUgZW50aXR5IGNvbnRleHQgaW5zdGFuY2UgcHJvdmlkaW5nIHNoYXJlZCBkYXRhIHRvIGFsbCBzdGF0ZXMgKi9cclxuICAgIHB1YmxpYyByZWFkb25seSBjb250ZXh0OiBJbnN0YW5jZVR5cGU8Q29udGV4dD47XHJcblxyXG4gICAgLyoqIFRoZSBjdXJyZW50IGxlYWYgc3RhdGUgYWRkcmVzcywgb3IgbnVsbCBpZiBubyBhY3RpdmUgc3RhdGUgKi9cclxuICAgIHByb3RlY3RlZCBjdXJyZW50QWRkcmVzczogc3RyaW5nIHwgbnVsbCA9IG51bGw7XHJcblxyXG4gICAgcHVibGljIHJlYWRvbmx5IHN0YXRlTWFwOiBSZWNvcmQ8c3RyaW5nLCBBYnN0cmFjdFN0YXRlW10+ID0ge307XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBXaGVuIHRydWUsIEFic3RyYWN0U3RhdGUuZW50ZXIoKSB3aWxsIHNraXAgY2FsbGluZyBvbkVudGVyIGFuZCBpbW1lZGlhdGVseVxyXG4gICAgICogdW5kbyB0aGUgYWN0aXZhdGlvbi4gU2V0IGJ5IHN1YmNsYXNzZXMgdG8gYWJvcnQgYSBjYXNjYWRlIG1pZC1mbGlnaHQuXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBpc0VudGVyQmxvY2tlZDogYm9vbGVhbiA9IGZhbHNlO1xyXG5cclxuICAgIC8qKlxyXG4gICAgICogQ2FsbGVkIGFmdGVyIG9uRW50ZXIoKSByZXR1cm5zIGZvciBhIHN1Y2Nlc3NmdWxseSBlbnRlcmVkIHN0YXRlLlxyXG4gICAgICogT3ZlcnJpZGUgaW4gc3ViY2xhc3NlcyB0byB0cmFjayBlbnRlci1kZXB0aCBvciBwZXJmb3JtIHBvc3QtZW50cnkgd29yay5cclxuICAgICAqL1xyXG4gICAgcHVibGljIG9uU3RhdGVFbnRlcmVkKCk6IHZvaWQge31cclxuXHJcbiAgICAvKipcclxuICAgICAqIENyZWF0ZXMgYSBuZXcgU3RhdGVDb21wb25lbnQgaW5zdGFuY2UuXHJcbiAgICAgKiBAcGFyYW0gZW50aXR5IC0gVGhlIGVudGl0eSB0aGlzIGNvbXBvbmVudCBpcyBhdHRhY2hlZCB0b1xyXG4gICAgICogQHBhcmFtIHJvb3RTdGF0ZUNsYXNzIC0gVGhlIHJvb3QgY29tcG9zaXRlIHN0YXRlIGNsYXNzXHJcbiAgICAgKiBAcGFyYW0gY29udGV4dCAtIFRoZSBjb250ZXh0IGNsYXNzIHRvIGluc3RhbnRpYXRlXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBjb25zdHJ1Y3RvcihlbnRpdHk6IEVudGl0eSwgcm9vdFN0YXRlQ2xhc3M6IENvbmNyZXRlU3RhdGVDbGFzczxDb21wb3NpdGVTdGF0ZT4sIGNvbnRleHQ6IENvbnRleHQpIHtcclxuICAgICAgICBzdXBlcihlbnRpdHksIDEpO1xyXG5cclxuICAgICAgICB0aGlzLmNvbnRleHQgPSBuZXcgY29udGV4dChlbnRpdHksIHRoaXMpIGFzIEluc3RhbmNlVHlwZTxDb250ZXh0PjtcclxuICAgICAgICB0aGlzLnJvb3QgPSBuZXcgcm9vdFN0YXRlQ2xhc3ModGhpcy5jb250ZXh0KTtcclxuXHJcbiAgICAgICAgY29uc3QgYWRkcmVzcyA9IHRoaXMucmVhZEFkZHJlc3NGcm9tU3RvcmUoKTtcclxuICAgICAgICBjb25zdCBzdHJpcHBlZEFkZHJlc3MgPSBhZGRyZXNzPy5zcGxpdChcIi9cIikuc3BsaWNlKDEpLmpvaW4oXCIvXCIpO1xyXG4gICAgICAgIHRoaXMucm9vdC5lbnRlcihzdHJpcHBlZEFkZHJlc3MpO1xyXG5cclxuICAgICAgICB0aGlzLm9uV29ybGRFdmVudChcIldvcmxkQWZ0ZXJFdmVudHNcIiwgXCJkYXRhRHJpdmVuRW50aXR5VHJpZ2dlclwiLCB0aGlzLm9uVHJpZ2dlci5iaW5kKHRoaXMpLCB7IGVudGl0aWVzOiBbdGhpcy5lbnRpdHldIH0pO1xyXG4gICAgICAgIHRoaXMub25Xb3JsZEV2ZW50KFwiU3lzdGVtQmVmb3JlRXZlbnRzXCIsIFwic2h1dGRvd25cIiwgdGhpcy5vblNodXRkb3duLmJpbmQodGhpcykpO1xyXG4gICAgICAgIHRoaXMub25Xb3JsZEV2ZW50KFwiV29ybGRBZnRlckV2ZW50c1wiLCBcImVudGl0eVJlbW92ZVwiLCB0aGlzLm9uRW50aXR5UmVtb3ZlZC5iaW5kKHRoaXMpLCB7IGVudGl0aWVzOiBbdGhpcy5lbnRpdHldIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogUHJvY2Vzc2VzIGEgc2luZ2xlIHRpY2sgZm9yIHRoZSBzdGF0ZSBtYWNoaW5lLCB1cGRhdGluZyBjb250ZXh0IGFuZCBhY3RpdmUgc3RhdGVzLlxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgcHJvY2VzcygpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmNvbnRleHQub25UaWNrKCk7XHJcbiAgICAgICAgdGhpcy5yb290LmFjdGl2ZVRpY2soKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEhhbmRsZXMgZGF0YS1kcml2ZW4gZW50aXR5IHRyaWdnZXIgZXZlbnRzXHJcbiAgICAgKiBAcGFyYW0gZXZlbnQgLSBUaGUgdHJpZ2dlciBldmVudFxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIG9uVHJpZ2dlcihldmVudDogRGF0YURyaXZlbkVudGl0eVRyaWdnZXJBZnRlckV2ZW50KTogdm9pZCB7XHJcbiAgICAgICAgY29uc3QgcGFydHMgPSBldmVudC5ldmVudElkLnNwbGl0KFwiLlwiKTtcclxuICAgICAgICBjb25zdCBbaWRlbnRpZmllciwgbWV0aG9kLCAuLi5sZWZ0b3Zlcl0gPSBwYXJ0cztcclxuICAgICAgICBjb25zdCBkYXRhID0gbGVmdG92ZXIuam9pbihcIi5cIik7XHJcblxyXG4gICAgICAgIHN3aXRjaCAobWV0aG9kKSB7XHJcbiAgICAgICAgICAgIGNhc2UgXCJzaWduYWxcIjpcclxuICAgICAgICAgICAgICAgIHRoaXMucm9vdC5oYW5kbGVTaWduYWwoaWRlbnRpZmllciwgZGF0YSBhcyBDb21tb25TaWduYWxzKTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKiogSGFuZGxlcyBlbnRpdHkgcmVtb3ZhbCBldmVudHMgKi9cclxuICAgIHByaXZhdGUgb25FbnRpdHlSZW1vdmVkKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMucm9vdC5leGl0KEV4aXRUeXBlLlJlbW92ZSk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBIYW5kbGVzIHdvcmxkIHNodXRkb3duIGJ5IHBlcnNpc3RpbmcgdGhlIGN1cnJlbnQgc3RhdGUgYW5kIGNsZWFuaW5nIHVwLlxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIG9uU2h1dGRvd24oKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy53cml0ZUFkZHJlc3NUb1N0b3JlKCk7XHJcbiAgICAgICAgdGhpcy5yb290LmV4aXQoRXhpdFR5cGUuU2h1dGRvd24pO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKiBIYW5kbGVzIHN0YXRlIGNoYW5nZSBldmVudHMgKi9cclxuICAgIHB1YmxpYyBvblN0YXRlQ2hhbmdlKG5ld0FkZHJlc3M6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuY3VycmVudEFkZHJlc3MgPSBuZXdBZGRyZXNzO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogUGVyc2lzdHMgdGhlIGN1cnJlbnQgbGVhZiBzdGF0ZSBhZGRyZXNzIHRvIGVudGl0eSBkeW5hbWljIHByb3BlcnRpZXMuXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgd3JpdGVBZGRyZXNzVG9TdG9yZSgpOiB2b2lkIHtcclxuICAgICAgICBjb25zdCBhZGRyZXNzID0gdGhpcy5yb290LmdldExlYWZBZGRyZXNzKCk7XHJcbiAgICAgICAgdGhpcy5lbnRpdHkuc2V0RHluYW1pY1Byb3BlcnR5KFN0YXRlQ29tcG9uZW50LkFERFJFU1NfS0VZLCBhZGRyZXNzKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFJlYWRzIHRoZSBwcmV2aW91c2x5IHBlcnNpc3RlZCBzdGF0ZSBhZGRyZXNzIGZyb20gZW50aXR5IGR5bmFtaWMgcHJvcGVydGllcy5cclxuICAgICAqIEByZXR1cm5zIFRoZSBzYXZlZCBzdGF0ZSBhZGRyZXNzLCBvciB1bmRlZmluZWQgaWYgbm9uZSBleGlzdHNcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSByZWFkQWRkcmVzc0Zyb21TdG9yZSgpOiBzdHJpbmcgfCB1bmRlZmluZWQge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmVudGl0eS5nZXREeW5hbWljUHJvcGVydHkoU3RhdGVDb21wb25lbnQuQUREUkVTU19LRVkpIGFzIHN0cmluZyB8IHVuZGVmaW5lZDtcclxuICAgIH1cclxuXHJcbiAgICAvKiogUmVnaXN0ZXJzIGEgc3RhdGUgaW5zdGFuY2Ugd2l0aCB0aGUgY29tcG9uZW50XHJcbiAgICAgKiBAcGFyYW0gc3RhdGUgLSBUaGUgc3RhdGUgaW5zdGFuY2UgdG8gcmVnaXN0ZXJcclxuICAgICAqL1xyXG4gICAgcHVibGljIHJlZ2lzdGVyU3RhdGUoc3RhdGU6IEFic3RyYWN0U3RhdGUpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLnN0YXRlTWFwW3N0YXRlLmlkZW50aWZpZXJdID8/PSBbXTtcclxuICAgICAgICB0aGlzLnN0YXRlTWFwW3N0YXRlLmlkZW50aWZpZXJdLnB1c2goc3RhdGUpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogRmluZHMgYWxsIGluc3RhbmNlcyBvZiBhIHN0YXRlIGNsYXNzIHJlZ2lzdGVyZWQgaW4gdGhpcyBjb21wb25lbnQuXHJcbiAgICAgKiBAcGFyYW0gc3RhdGVDbGFzcyAtIFRoZSBjbGFzcyB0byBzZWFyY2ggZm9yXHJcbiAgICAgKiBAcGFyYW0gaXNBY3RpdmVPbmx5IC0gV2hldGhlciB0byBvbmx5IGluY2x1ZGUgYWN0aXZlIHN0YXRlcyBpbiB0aGUgcmVzdWx0c1xyXG4gICAgICogQHJldHVybnMgQW4gYXJyYXkgb2YgbWF0Y2hpbmcgc3RhdGUgaW5zdGFuY2VzXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBmaW5kQWxsPFMgZXh0ZW5kcyBBYnN0cmFjdFN0YXRlPihzdGF0ZUNsYXNzOiBTdGF0ZUNsYXNzPFM+LCBpc0FjdGl2ZU9ubHk6IGJvb2xlYW4gPSBmYWxzZSk6IFNbXSB7XHJcbiAgICAgICAgY29uc3Qgc3RhdGVzID0gKHRoaXMuc3RhdGVNYXBbc3RhdGVDbGFzcy5pZGVudGlmaWVyXSA/PyBbXSkgYXMgU1tdO1xyXG4gICAgICAgIHJldHVybiBpc0FjdGl2ZU9ubHkgPyBzdGF0ZXMuZmlsdGVyKChzKSA9PiBzLmlzQWN0aXZlKSA6IHN0YXRlcztcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEZpbmRzIHRoZSBmaXJzdCBpbnN0YW5jZSBvZiBhIHN0YXRlIGNsYXNzIHJlZ2lzdGVyZWQgaW4gdGhpcyBjb21wb25lbnQuXHJcbiAgICAgKiBAcGFyYW0gc3RhdGVDbGFzcyAtIFRoZSBjbGFzcyB0byBzZWFyY2ggZm9yXHJcbiAgICAgKiBAcGFyYW0gaXNBY3RpdmVPbmx5IC0gV2hldGhlciB0byBvbmx5IGNvbnNpZGVyIGFjdGl2ZSBzdGF0ZXNcclxuICAgICAqIEByZXR1cm5zIFRoZSBmaXJzdCBtYXRjaGluZyBzdGF0ZSBpbnN0YW5jZSwgb3IgbnVsbCBpZiBub25lIGZvdW5kXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBmaW5kRmlyc3Q8UyBleHRlbmRzIEFic3RyYWN0U3RhdGU+KHN0YXRlQ2xhc3M6IFN0YXRlQ2xhc3M8Uz4sIGlzQWN0aXZlT25seTogYm9vbGVhbiA9IGZhbHNlKTogUyB8IG51bGwge1xyXG4gICAgICAgIGNvbnN0IHN0YXRlcyA9ICh0aGlzLnN0YXRlTWFwW3N0YXRlQ2xhc3MuaWRlbnRpZmllcl0gPz8gW10pIGFzIFNbXTtcclxuICAgICAgICByZXR1cm4gKGlzQWN0aXZlT25seSA/IHN0YXRlcy5maW5kKChzKSA9PiBzLmlzQWN0aXZlKSA6IHN0YXRlc1swXSkgPz8gbnVsbDtcclxuICAgIH1cclxuXHJcbiAgICAvKiogQ2hlY2tzIGlmIGFueSBhY3RpdmUgc3RhdGUgb2YgdGhlIHNwZWNpZmllZCBjbGFzcyBleGlzdHMgaW4gdGhpcyBjb21wb25lbnQuXHJcbiAgICAgKiBAcGFyYW0gc3RhdGVDbGFzcyAtIFRoZSBjbGFzcyB0byBjaGVjayBmb3JcclxuICAgICAqIEByZXR1cm5zIFRydWUgaWYgYW4gYWN0aXZlIHN0YXRlIG9mIHRoZSBjbGFzcyBleGlzdHMsIGZhbHNlIG90aGVyd2lzZVxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgaGFzQWN0aXZlU3RhdGUoc3RhdGVDbGFzczogU3RhdGVDbGFzcyk6IGJvb2xlYW4ge1xyXG4gICAgICAgIGNvbnN0IHN0YXRlcyA9IHRoaXMuc3RhdGVNYXBbc3RhdGVDbGFzcy5pZGVudGlmaWVyXSA/PyBbXTtcclxuICAgICAgICByZXR1cm4gc3RhdGVzLnNvbWUoKHMpID0+IHMuaXNBY3RpdmUpO1xyXG4gICAgfVxyXG59XHJcbiJdLCJuYW1lcyI6WyJBYnN0cmFjdE1vYkNvbXBvbmVudCIsIkV4aXRUeXBlIiwiU3RhdGVDb21wb25lbnQiLCJvblN0YXRlRW50ZXJlZCIsInByb2Nlc3MiLCJjb250ZXh0Iiwib25UaWNrIiwicm9vdCIsImFjdGl2ZVRpY2siLCJvblRyaWdnZXIiLCJldmVudCIsInBhcnRzIiwiZXZlbnRJZCIsInNwbGl0IiwiaWRlbnRpZmllciIsIm1ldGhvZCIsImxlZnRvdmVyIiwiZGF0YSIsImpvaW4iLCJoYW5kbGVTaWduYWwiLCJvbkVudGl0eVJlbW92ZWQiLCJleGl0IiwiUmVtb3ZlIiwib25TaHV0ZG93biIsIndyaXRlQWRkcmVzc1RvU3RvcmUiLCJTaHV0ZG93biIsIm9uU3RhdGVDaGFuZ2UiLCJuZXdBZGRyZXNzIiwiY3VycmVudEFkZHJlc3MiLCJhZGRyZXNzIiwiZ2V0TGVhZkFkZHJlc3MiLCJlbnRpdHkiLCJzZXREeW5hbWljUHJvcGVydHkiLCJBRERSRVNTX0tFWSIsInJlYWRBZGRyZXNzRnJvbVN0b3JlIiwiZ2V0RHluYW1pY1Byb3BlcnR5IiwicmVnaXN0ZXJTdGF0ZSIsInN0YXRlIiwic3RhdGVNYXAiLCJwdXNoIiwiZmluZEFsbCIsInN0YXRlQ2xhc3MiLCJpc0FjdGl2ZU9ubHkiLCJzdGF0ZXMiLCJmaWx0ZXIiLCJzIiwiaXNBY3RpdmUiLCJmaW5kRmlyc3QiLCJmaW5kIiwiaGFzQWN0aXZlU3RhdGUiLCJzb21lIiwicm9vdFN0YXRlQ2xhc3MiLCJpc0VudGVyQmxvY2tlZCIsInN0cmlwcGVkQWRkcmVzcyIsInNwbGljZSIsImVudGVyIiwib25Xb3JsZEV2ZW50IiwiYmluZCIsImVudGl0aWVzIl0sIm1hcHBpbmdzIjoiQUFDQSxPQUFPQSwwQkFBMEIscUNBQXFDO0FBR3RFLFNBQWdFQyxRQUFRLFFBQW9CLFVBQVU7QUFVdkYsTUFBZUMsdUJBQWdGRjtJQW9CMUc7OztLQUdDLEdBQ0QsQUFBT0csaUJBQXVCLENBQUM7SUF1Qi9COztLQUVDLEdBQ0QsQUFBT0MsVUFBZ0I7UUFDbkIsSUFBSSxDQUFDQyxPQUFPLENBQUNDLE1BQU07UUFDbkIsSUFBSSxDQUFDQyxJQUFJLENBQUNDLFVBQVU7SUFDeEI7SUFFQTs7O0tBR0MsR0FDRCxBQUFRQyxVQUFVQyxLQUF3QyxFQUFRO1FBQzlELE1BQU1DLFFBQVFELE1BQU1FLE9BQU8sQ0FBQ0MsS0FBSyxDQUFDO1FBQ2xDLE1BQU0sQ0FBQ0MsWUFBWUMsUUFBUSxHQUFHQyxTQUFTLEdBQUdMO1FBQzFDLE1BQU1NLE9BQU9ELFNBQVNFLElBQUksQ0FBQztRQUUzQixPQUFRSDtZQUNKLEtBQUs7Z0JBQ0QsSUFBSSxDQUFDUixJQUFJLENBQUNZLFlBQVksQ0FBQ0wsWUFBWUc7Z0JBQ25DO1FBQ1I7SUFDSjtJQUVBLGtDQUFrQyxHQUNsQyxBQUFRRyxrQkFBd0I7UUFDNUIsSUFBSSxDQUFDYixJQUFJLENBQUNjLElBQUksQ0FBQ3BCLFNBQVNxQixNQUFNO0lBQ2xDO0lBRUE7O0tBRUMsR0FDRCxBQUFRQyxhQUFtQjtRQUN2QixJQUFJLENBQUNDLG1CQUFtQjtRQUN4QixJQUFJLENBQUNqQixJQUFJLENBQUNjLElBQUksQ0FBQ3BCLFNBQVN3QixRQUFRO0lBQ3BDO0lBRUEsZ0NBQWdDLEdBQ2hDLEFBQU9DLGNBQWNDLFVBQWtCLEVBQVE7UUFDM0MsSUFBSSxDQUFDQyxjQUFjLEdBQUdEO0lBQzFCO0lBRUE7O0tBRUMsR0FDRCxBQUFRSCxzQkFBNEI7UUFDaEMsTUFBTUssVUFBVSxJQUFJLENBQUN0QixJQUFJLENBQUN1QixjQUFjO1FBQ3hDLElBQUksQ0FBQ0MsTUFBTSxDQUFDQyxrQkFBa0IsQ0FBQzlCLGVBQWUrQixXQUFXLEVBQUVKO0lBQy9EO0lBRUE7OztLQUdDLEdBQ0QsQUFBUUssdUJBQTJDO1FBQy9DLE9BQU8sSUFBSSxDQUFDSCxNQUFNLENBQUNJLGtCQUFrQixDQUFDakMsZUFBZStCLFdBQVc7SUFDcEU7SUFFQTs7S0FFQyxHQUNELEFBQU9HLGNBQWNDLEtBQW9CLEVBQVE7WUFDN0MsZ0JBQWNBO1FBQWQsQ0FBQSxpQkFBQSxJQUFJLENBQUNDLFFBQVEsQ0FBQSxDQUFDRCxvQkFBQUEsTUFBTXZCLFVBQVUsQ0FBQyxLQUEvQixjQUFhLENBQUN1QixrQkFBaUIsR0FBSyxFQUFFO1FBQ3RDLElBQUksQ0FBQ0MsUUFBUSxDQUFDRCxNQUFNdkIsVUFBVSxDQUFDLENBQUN5QixJQUFJLENBQUNGO0lBQ3pDO0lBRUE7Ozs7O0tBS0MsR0FDRCxBQUFPRyxRQUFpQ0MsVUFBeUIsRUFBRUMsZUFBd0IsS0FBSyxFQUFPO1FBQ25HLE1BQU1DLFNBQVUsSUFBSSxDQUFDTCxRQUFRLENBQUNHLFdBQVczQixVQUFVLENBQUMsSUFBSSxFQUFFO1FBQzFELE9BQU80QixlQUFlQyxPQUFPQyxNQUFNLENBQUMsQ0FBQ0MsSUFBTUEsRUFBRUMsUUFBUSxJQUFJSDtJQUM3RDtJQUVBOzs7OztLQUtDLEdBQ0QsQUFBT0ksVUFBbUNOLFVBQXlCLEVBQUVDLGVBQXdCLEtBQUssRUFBWTtRQUMxRyxNQUFNQyxTQUFVLElBQUksQ0FBQ0wsUUFBUSxDQUFDRyxXQUFXM0IsVUFBVSxDQUFDLElBQUksRUFBRTtRQUMxRCxPQUFPLEFBQUM0QixDQUFBQSxlQUFlQyxPQUFPSyxJQUFJLENBQUMsQ0FBQ0gsSUFBTUEsRUFBRUMsUUFBUSxJQUFJSCxNQUFNLENBQUMsRUFBRSxBQUFELEtBQU07SUFDMUU7SUFFQTs7O0tBR0MsR0FDRCxBQUFPTSxlQUFlUixVQUFzQixFQUFXO1FBQ25ELE1BQU1FLFNBQVMsSUFBSSxDQUFDTCxRQUFRLENBQUNHLFdBQVczQixVQUFVLENBQUMsSUFBSSxFQUFFO1FBQ3pELE9BQU82QixPQUFPTyxJQUFJLENBQUMsQ0FBQ0wsSUFBTUEsRUFBRUMsUUFBUTtJQUN4QztJQXBIQTs7Ozs7S0FLQyxHQUNELFlBQW1CZixNQUFjLEVBQUVvQixjQUFrRCxFQUFFOUMsT0FBZ0IsQ0FBRTtRQUNyRyxLQUFLLENBQUMwQixRQUFRO1FBeEJsQiwrREFBK0QsUUFDckRILGlCQUFnQzthQUUxQlUsV0FBNEMsQ0FBQztRQUU3RDs7O0tBR0MsUUFDTWMsaUJBQTBCO1FBaUI3QixJQUFJLENBQUMvQyxPQUFPLEdBQUcsSUFBSUEsUUFBUTBCLFFBQVEsSUFBSTtRQUN2QyxJQUFJLENBQUN4QixJQUFJLEdBQUcsSUFBSTRDLGVBQWUsSUFBSSxDQUFDOUMsT0FBTztRQUUzQyxNQUFNd0IsVUFBVSxJQUFJLENBQUNLLG9CQUFvQjtRQUN6QyxNQUFNbUIsa0JBQWtCeEIsU0FBU2hCLE1BQU0sS0FBS3lDLE9BQU8sR0FBR3BDLEtBQUs7UUFDM0QsSUFBSSxDQUFDWCxJQUFJLENBQUNnRCxLQUFLLENBQUNGO1FBRWhCLElBQUksQ0FBQ0csWUFBWSxDQUFDLG9CQUFvQiwyQkFBMkIsSUFBSSxDQUFDL0MsU0FBUyxDQUFDZ0QsSUFBSSxDQUFDLElBQUksR0FBRztZQUFFQyxVQUFVO2dCQUFDLElBQUksQ0FBQzNCLE1BQU07YUFBQztRQUFDO1FBQ3RILElBQUksQ0FBQ3lCLFlBQVksQ0FBQyxzQkFBc0IsWUFBWSxJQUFJLENBQUNqQyxVQUFVLENBQUNrQyxJQUFJLENBQUMsSUFBSTtRQUM3RSxJQUFJLENBQUNELFlBQVksQ0FBQyxvQkFBb0IsZ0JBQWdCLElBQUksQ0FBQ3BDLGVBQWUsQ0FBQ3FDLElBQUksQ0FBQyxJQUFJLEdBQUc7WUFBRUMsVUFBVTtnQkFBQyxJQUFJLENBQUMzQixNQUFNO2FBQUM7UUFBQztJQUNySDtBQWtHSjtBQS9JOEI3QixlQUNGK0IsY0FBYztBQVQxQzs7Ozs7OztDQU9DLEdBQ0QsU0FBOEIvQiw0QkErSTdCIn0=