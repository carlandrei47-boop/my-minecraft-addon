import { HealthVar } from "BigBrain/Context/HealthVar";
import { LastHitByEntityVar } from "BigBrain/Context/LastHitByEntityVar";
import { NearbyEnemiesVar } from "BigBrain/Context/NearbyEnemiesVar";
import { NearestPlayerLastHitByEntity } from "BigBrain/Context/NearestPlayerLastHitByEntity";
import { NearestVisibleEnemyVar } from "BigBrain/Context/NearestVisibleEnemyVar";
import { MeleeAttackProcedure } from "BigBrain/Procedures/MeleeAttackProcedure";
import { FleeStep } from "BigBrain/Steps/FleeStep";
import CombatRoutineData from "Data/BigBrain/Routines/CombatRoutineData";
import DejectionComponent from "MobComponents/Components/DejectionComponent";
import CompositeState from "StateSkeleton/States/CompositeState";
import { ItemStack } from "@minecraft/server";
import { PillarCleaner } from "../../Utils/PillarCleaner.js";

const registry = [
    MeleeAttackProcedure,
    FleeStep
];

export class CombatRoutine extends CompositeState {
    computeScore() {
        const isLessThanMinimumDuration = this.isActive && this.activeTicks < CombatRoutineData.MinimumActiveDuration;
        const isDejected = DejectionComponent.get(this.context.entity).isDejected();
        if (isLessThanMinimumDuration && !isDejected) return CombatRoutineData.BaseScore;

        const lastHitByEnemy = this.context.getValue(LastHitByEntityVar);
        if (lastHitByEnemy !== null) {
            const ticksSinceLastHit = Main.currentTick - lastHitByEnemy.timestamp;
            const wasRecentlyHit = ticksSinceLastHit < CombatRoutineData.LastHitRecencyDuration;
            if (wasRecentlyHit) return CombatRoutineData.BaseScore;
        }

        const nearestPlayerLastHitByEnemy = this.context.getValue(NearestPlayerLastHitByEntity);
        const isInCoop = EntityStore.get(this.context.entity, "inCoopMode");
        if (nearestPlayerLastHitByEnemy !== null && isInCoop) {
            const ticksSincePlayerWasHit = Main.currentTick - nearestPlayerLastHitByEnemy.timestamp;
            const wasPlayerRecentlyHit = ticksSincePlayerWasHit < CombatRoutineData.LastHitRecencyDuration;
            if (wasPlayerRecentlyHit) return CombatRoutineData.BaseScore;
        }

        const nearestVisibleEnemy = this.context.getValue(NearestVisibleEnemyVar);
        if (nearestVisibleEnemy !== null) {
            const isWithinRange = nearestVisibleEnemy.distance < CombatRoutineData.MaxVisibleEnemyDistance;
            if (isWithinRange) return CombatRoutineData.BaseScore;
        }

        return 0;
    }

    onActiveTick() {
        // 1. Endgame Emergency Protocols (Totem, Pearl Escape, Regen)
        if (this.handleEndgameEmergency()) return;

        // 2. Tactical Off-hand & Shield Check
        this.handleOffhandShield();

        // 3. Creeper Defusal Check
        if (this.handleCreeperSentry()) {
            this.tryFlee();
            return;
        }

        // 4. Swarm Emergency Pillar Check
        this.tryEmergencyPillar();

        if (this.activeTicks % CombatRoutineData.ConfidenceUpdateInterval !== 0) return;

        this.confidence = this.computeConfidence();
        if (this.confidence <= CombatRoutineData.FleeConfidenceThreshold) this.tryFlee();
        else this.tryMeleeAttack();
    }

    /**
     * Endgame Emergency Protocols: Totem swap, Ender Pearl escape, and combat healing
     */
    handleEndgameEmergency() {
        const entity = this.context.entity;
        if (!entity?.isValid) return false;

        const health = this.context.getValue(HealthVar);
        const currentHp = health?.currentHealth ?? 20;
        const inv = entity.getComponent("minecraft:inventory")?.container;
        const equippable = entity.getComponent("minecraft:equippable");
        const nearbyEnemies = this.context.getValue(NearbyEnemiesVar) ?? [];

        if (inv && equippable) {
            // 1. Totem of Undying auto-swap to off-hand (< 7 HP)
            if (currentHp <= 7) {
                const offhand = equippable.getEquipment("Offhand");
                if (!offhand || offhand.typeId !== "minecraft:totem_of_undying") {
                    for (let i = 0; i < inv.size; i++) {
                        const item = inv.getItem(i);
                        if (item?.typeId === "minecraft:totem_of_undying") {
                            equippable.setEquipment("Offhand", item);
                            inv.setItem(i, offhand ?? undefined);
                            break;
                        }
                    }
                }
            }

            // 2. Ender Pearl Panic Escape (< 5 HP or surrounded by 4+ mobs)
            if ((currentHp <= 5 || nearbyEnemies.length >= 4) && Main.currentTick % 40 === 0) {
                let pearlSlot = -1;
                for (let i = 0; i < inv.size; i++) {
                    const item = inv.getItem(i);
                    if (item?.typeId === "minecraft:ender_pearl") {
                        pearlSlot = i;
                        break;
                    }
                }

                if (pearlSlot !== -1) {
                    let avgX = 0;
                    let avgZ = 0;
                    for (const mob of nearbyEnemies) {
                        avgX += mob.location.x;
                        avgZ += mob.location.z;
                    }
                    avgX /= (nearbyEnemies.length || 1);
                    avgZ /= (nearbyEnemies.length || 1);

                    const dx = entity.location.x - avgX;
                    const dz = entity.location.z - avgZ;
                    const len = Math.hypot(dx, dz) || 1;

                    const escapeX = Math.floor(entity.location.x + (dx / len) * 16);
                    const escapeZ = Math.floor(entity.location.z + (dz / len) * 16);
                    const escapeY = Math.floor(entity.location.y);

                    const pearlItem = inv.getItem(pearlSlot);
                    if (pearlItem.amount <= 1) inv.setItem(pearlSlot, undefined);
                    else { pearlItem.amount -= 1; inv.setItem(pearlSlot, pearlItem); }

                    entity.dimension.spawnParticle("minecraft:ender_pearl_teleport", entity.location);
                    entity.teleport({ x: escapeX, y: escapeY, z: escapeZ }, { dimension: entity.dimension });
                    this.tryFlee();
                    return true;
                }
            }

            // 3. Emergency Food / Regen (Golden Apple / Health Potion)
            if (currentHp <= 10 && !entity.hasTag("regenerating")) {
                for (let i = 0; i < inv.size; i++) {
                    const item = inv.getItem(i);
                    if (item?.typeId.includes("golden_apple") || item?.typeId.includes("healing")) {
                        entity.addEffect("regeneration", 100, { amplifier: 1, showParticles: true });
                        if (item.amount <= 1) inv.setItem(i, undefined);
                        else { item.amount -= 1; inv.setItem(i, item); }
                        break;
                    }
                }
            }
        }

        return false;
    }

    /**
     * Auto-equips shield to offhand and raises guard against projectiles or critical attacks
     */
    handleOffhandShield() {
        const entity = this.context.entity;
        if (!entity?.isValid) return;

        const equippable = entity.getComponent("minecraft:equippable");
        if (!equippable) return;

        const offhand = equippable.getEquipment("Offhand");
        if (!offhand || (offhand.typeId !== "minecraft:shield" && offhand.typeId !== "minecraft:totem_of_undying")) {
            try {
                equippable.setEquipment("Offhand", new ItemStack("minecraft:shield", 1));
            } catch {}
        }

        const lastHit = this.context.getValue(LastHitByEntityVar);
        if (lastHit && (Main.currentTick - lastHit.timestamp < 30)) {
            entity.isSneaking = true;
        } else if (entity.isSneaking && !this.isCrouchBridging()) {
            entity.isSneaking = false;
        }
    }

    isCrouchBridging() {
        return false;
    }

    handleCreeperSentry() {
        const nearbyEnemies = this.context.getValue(NearbyEnemiesVar) ?? [];
        for (const enemy of nearbyEnemies) {
            if (enemy.typeId === "minecraft:creeper") {
                const dist = this.context.entity.location;
                const eLoc = enemy.location;
                const dx = dist.x - eLoc.x;
                const dz = dist.z - eLoc.z;
                const distanceSq = dx * dx + dz * dz;

                if (distanceSq < 49) {
                    return true;
                }
            }
        }
        return false;
    }

    tryEmergencyPillar() {
        const health = this.context.getValue(HealthVar);
        const healthPct = (health?.currentHealth ?? 20) / (health?.maxHealth || 20);
        const nearbyEnemies = this.context.getValue(NearbyEnemiesVar) ?? [];

        if (healthPct < 0.5 && nearbyEnemies.length >= 3) {
            const ent = this.context.entity;
            const dim = ent.dimension;
            const loc = ent.location;
            const blockLoc = {
                x: Math.floor(loc.x),
                y: Math.floor(loc.y) - 1,
                z: Math.floor(loc.z)
            };

            try {
                dim.runCommand(`setblock ${blockLoc.x} ${blockLoc.y} ${blockLoc.z} cobblestone`);
                dim.runCommand(`setblock ${blockLoc.x} ${blockLoc.y + 1} ${blockLoc.z} cobblestone`);
                ent.teleport({ x: blockLoc.x + 0.5, y: blockLoc.y + 2, z: blockLoc.z + 0.5 });

                PillarCleaner.registerTemporaryBlock(dim, { x: blockLoc.x, y: blockLoc.y, z: blockLoc.z });
                PillarCleaner.registerTemporaryBlock(dim, { x: blockLoc.x, y: blockLoc.y + 1, z: blockLoc.z });
            } catch {}
        }
    }

    computeConfidence() {
        if (this.context.entity.isInWater) return -1;

        const health = this.context.getValue(HealthVar);
        const nearbyEnemies = this.context.getValue(NearbyEnemiesVar) ?? [];

        const healthPercentage = (health?.currentHealth ?? 20) / (health?.maxHealth || 20);

        if (healthPercentage < 0.35) return -1;

        const healthConfidence = MathUtil.lerp(
            CombatRoutineData.HealthConfidenceRange[0],
            CombatRoutineData.HealthConfidenceRange[1],
            healthPercentage
        );

        let enemyPenalty = 0;
        for (const enemy of nearbyEnemies) {
            const enemyType = enemy.typeId;
            const penaltyForEnemy = CombatRoutineData.EnemyConfidencePenalty[enemyType] ?? CombatRoutineData.DefaultEnemyConfidencePenalty;
            enemyPenalty += penaltyForEnemy;
        }

        return healthConfidence - enemyPenalty;
    }

    onSubstateFailure(state) {
        if (state.is(FleeStep)) {
            this.lastFleeTimestamp = Main.currentTick;
            return this.tryMeleeAttack();
        }
        if (state.is(MeleeAttackProcedure)) {
            this.lastMeleeAttackTimestamp = Main.currentTick;
            return this.tryFlee();
        }
        this.broadcastSignal("onFailure");
    }

    tryFlee() {
        if (this.currentSubstate?.is(FleeStep)) return;
        const isOnCooldown = Main.currentTick - this.lastFleeTimestamp < CombatRoutineData.FleeCooldown;
        if (isOnCooldown) return;
        this.setSubstate(this.getSubstate(FleeStep));
    }

    tryMeleeAttack() {
        if (this.currentSubstate?.is(MeleeAttackProcedure)) return;
        const isOnCooldown = Main.currentTick - this.lastMeleeAttackTimestamp < CombatRoutineData.MeleeAttackCooldown;
        if (isOnCooldown) return;
        this.setSubstate(this.getSubstate(MeleeAttackProcedure));
    }

    constructor(...args) {
        super(...args);
        this.lastFleeTimestamp = -Infinity;
        this.lastMeleeAttackTimestamp = -Infinity;
        this.confidence = 0;
    }
}

CombatRoutine.definition = {
    identifier: "routine:combat",
    priority: CombatRoutineData.Priority,
    registry,
    initialState: MeleeAttackProcedure
};
