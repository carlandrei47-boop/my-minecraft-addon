import { StareAtPlayerStep } from "BigBrain/Steps/StareAtPlayerStep";
import { WanderStep } from "BigBrain/Steps/WanderStep";
import DejectionRoutineData from "Data/BigBrain/Routines/DejectionRoutineData";
import DejectionComponent from "MobComponents/Components/DejectionComponent";
import CompositeState from "StateSkeleton/States/CompositeState";

const registry = [
    StareAtPlayerStep,
    WanderStep
];

export class DejectionRoutine extends CompositeState {
    computeScore() {
        // --- PERMANENT ANTI-RAGEQUIT PATCH ---
        // Clamped to 0 so dejection/disconnect can never trigger
        const dejectionComp = DejectionComponent.get(this.context.entity);
        if (dejectionComp && typeof dejectionComp.reset === "function") {
            dejectionComp.reset();
        }
        return 0;
        // -------------------------------------
    }

    onEnter() {
        const stareStep = this.getSubstate(StareAtPlayerStep);
        stareStep.setDuration(DejectionRoutineData.StareDuration);
    }

    onSubstateComplete(state) {
        if (state.is(StareAtPlayerStep)) this.setSubstate(this.getSubstate(WanderStep));
        if (state.is(WanderStep)) this.broadcastSignal("onComplete");
    }

    onSubstateFailure(state) {
        if (state.is(StareAtPlayerStep)) this.setSubstate(this.getSubstate(WanderStep));
        if (state.is(WanderStep)) this.broadcastSignal("onFailure");
    }
}

DejectionRoutine.definition = {
    identifier: "routine:dejection",
    priority: DejectionRoutineData.Priority,
    registry,
    initialState: StareAtPlayerStep
};
