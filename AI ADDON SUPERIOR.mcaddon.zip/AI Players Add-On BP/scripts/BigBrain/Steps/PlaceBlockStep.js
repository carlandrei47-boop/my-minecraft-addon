import { BaseGuard } from "../../Utils/BaseGuard.js";
import { ItemStack } from "@minecraft/server";
import { LocationVar } from "BigBrain/Context/LocationVar";
import PlaceBlockStepData from "Data/BigBrain/Steps/PlaceBlockStepData";
import BlockSoundEffectData from "Data/BlockSoundEffectData";
import V3 from "Helpers/Vectors/V3";
import VirtualInventoryComponent from "Inventory/VirtualInventoryComponent";
import AbstractState from "StateSkeleton/States/AbstractState";
import { ExitType } from "StateSkeleton/Types";
import BlockUtils from "Utils/BlockUtils";

export class PlaceBlockStep extends AbstractState {
    setPermutation(permutation) {
        if (this.isActive) return;
        this.permutation = permutation;
    }

    setLocation(location) {
        if (this.isActive) return;
        this.location = location;
    }

    setRemoveFromInventory(shouldRemove) {
        if (this.isActive) return;
        this.removeFromInventory = shouldRemove;
    }

    onEnter() {
        if (!this.permutation || !this.location) return this.broadcastSignal("onComplete");

        // --- BASE PROTECTION GUARD ---
        const dimension = this.location.dimension ?? this.context.entity.dimension;
        if (BaseGuard.isInsideSafeZone(dimension, this.location)) {
            return this.broadcastSignal("onComplete");
        }
        // ------------------------------

        this.context.entity.setProperty("gm1_sky:is_using_item", "swinging");
    }

    onExit(_exitType) {
        if (_exitType !== ExitType.Standard) return;
        this.context.entity.setProperty("gm1_sky:is_using_item", "idle");
    }

    onActiveTick() {
        if (this.activeTicks === PlaceBlockStepData.DelayBeforePlacing) {
            this.placeBlock(this.permutation, this.location);
        }
    }

    placeBlock(permutation, location) {
        if (!location || !permutation) return this.broadcastSignal("onFailure");

        const dimension = location.dimension ?? this.context.entity.dimension ?? overworld;

        // --- BASE PROTECTION GUARD (FAILSAFE) ---
        if (BaseGuard.isInsideSafeZone(dimension, location)) {
            return this.broadcastSignal("onFailure");
        }
        // ----------------------------------------

        const currentBlock = BlockUtils.fromV3(location);
        if (!currentBlock?.isValid || !BlockUtils.isOverrideable(currentBlock.permutation)) return this.broadcastSignal("onFailure");

        if (this.isOccupiedByBlockingEntity(location, dimension)) {
            return this.broadcastSignal("onFailure");
        }

        dimension.setBlockPermutation(location, permutation);
        dimension.playSound(BlockSoundEffectData.getPlacedSound(permutation.type.id), location);
        this.tryRotateBlockTowardsEntity(dimension);

        if (this.removeFromInventory) {
            VirtualInventoryComponent.get(this.context.entity).removeItem(new ItemStack(permutation.type.id));
        }

        this.broadcastSignal("onComplete");
    }

    isOccupiedByBlockingEntity(location, dimension) {
        const entities = dimension.getEntities({
            location: location,
            // A zero volume detects entities at this block
            volume: V3.Zero,
            excludeTypes: PlaceBlockStepData.NonBlockingEntityTypes
        });
        return entities.some((entity) => entity.id !== this.context.entity.id);
    }

    tryRotateBlockTowardsEntity(dimension) {
        if (!this.permutation || !this.location) return false;
        const block = dimension.getBlock(this.location);
        if (block === undefined) return false;

        const entityLocation = this.context.getValue(LocationVar).$.grid();
        const blockLocation = this.location.grid();
        const dx = entityLocation.x - blockLocation.x;
        const dz = entityLocation.z - blockLocation.z;

        let facing;
        if (Math.abs(dx) >= Math.abs(dz)) {
            facing = dx > 0 ? "east" : "west";
        } else {
            facing = dz > 0 ? "south" : "north";
        }

        if (this.permutation.getState("minecraft:cardinal_direction") === undefined) return false;
        block.setPermutation(this.permutation.withState("minecraft:cardinal_direction", facing));
        return true;
    }

    constructor(...args) {
        super(...args);
        this.permutation = null;
        this.location = null;
        this.removeFromInventory = true;
    }
}

PlaceBlockStep.definition = {
    identifier: "step:place_block",
    priority: PlaceBlockStepData.Priority
};
