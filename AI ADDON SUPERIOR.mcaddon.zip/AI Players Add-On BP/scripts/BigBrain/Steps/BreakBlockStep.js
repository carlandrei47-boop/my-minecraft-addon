import { BaseGuard } from "../../Utils/BaseGuard.js";
import { world } from "@minecraft/server";
import BreakBlockStepData from "Data/BigBrain/Steps/BreakBlockStepData";
import BlockMiningData from "Data/BlockMiningData";
import BlockSoundEffectData from "Data/BlockSoundEffectData";
import V3 from "Helpers/Vectors/V3";
import AbstractState from "StateSkeleton/States/AbstractState";
import { ExitType } from "StateSkeleton/Types";
import BlockUtils from "Utils/BlockUtils";

export class BreakBlockStep extends AbstractState {
    setBlock(block) {
        // Can't change the block while the step is active
        if (this.isActive) return;
        this.block = block;
    }

    setDropLoot(dropLoot) {
        // Can't change drop loot while the step is active
        if (this.isActive) return;
        this.dropLoot = dropLoot;
    }

    setBreakDuration(duration) {
        // Can't change break duration while the step is active
        if (this.isActive) return;
        this.breakDuration = duration;
    }

    onEnter() {
        if (!this.block?.isValid) return this.broadcastSignal("onComplete");

        // --- BASE PROTECTION GUARD ---
        const dimension = this.context.entity.dimension;
        if (BaseGuard.isInsideSafeZone(dimension, this.block.location)) {
            return this.broadcastSignal("onComplete");
        }
        // ------------------------------

        this.blockLocation = V3.fromBlock(this.block, overworld).grid();
        this.spawnBlockBreakerEffect(this.blockLocation);
        this.blockTypeId = this.block.typeId;
    }

    onExit(_exitType) {
        if (_exitType === ExitType.Shutdown) return;
        if (this.blockBreakerEntity) {
            if (this.blockBreakerEntity.isValid) this.blockBreakerEntity.remove();
            this.blockBreakerEntity = null;
        }
        if (_exitType !== ExitType.Standard) return;
        this.context.entity.setProperty("gm1_sky:is_using_item", "idle");
    }

    onActiveTick() {
        if (this.hasBlockChanged()) return this.broadcastSignal("onComplete");
        if (Main.currentTick % BreakBlockStepData.SwingInterval === 0) this.executeSwing();
        if (this.activeTicks % BreakBlockStepData.ValidityCheckDuration === 0) this.broadcastFailureIfInvalid();
        if (this.activeTicks >= this.breakDuration) this.breakBlock(this.block);
    }

    hasBlockChanged() {
        if (!this.block?.isValid) return true;
        const currentTypeId = this.block.typeId;
        if (BlockMiningData.BlockValidityMap[this.blockTypeId] === currentTypeId) return false;
        return currentTypeId !== this.blockTypeId;
    }

    broadcastFailureIfInvalid() {
        if (this.block?.isAir) return this.broadcastSignal("onFailure");
        if (!BlockUtils.canHighlightBlock(this.context.entity, this.block)) return this.broadcastSignal("onFailure");
    }

    executeSwing() {
        if (!this.block?.isValid) return this.broadcastSignal("onComplete");
        const dimension = this.context.entity.dimension;
        const soundOptions = {
            volume: BlockSoundEffectData.DefaultHitSoundVolume,
            pitch: BlockSoundEffectData.DefaultHitSoundPitch
        };
        dimension.playSound(BlockSoundEffectData.getHitSound(this.block.typeId), this.blockLocation, soundOptions);
        this.context.entity.setProperty("gm1_sky:is_using_item", "swinging");
    }

    spawnBlockBreakerEffect(blockLocation) {
        if (this.breakDuration <= 0) return;
        // Spawns 1 block up (1.0) minus the slight offset (0.01) so the texture is visible on the bottom face
        const spawnLocation = blockLocation.add(new V3(0, 0.99, 0));
        if (!blockLocation.isLoaded()) return;
        this.blockBreakerEntity = EntityUtil.spawnEntity("gm1_sky:block_breaker", spawnLocation);
        this.blockBreakerEntity.setProperty("gm1_sky:break_duration", this.breakDuration);
    }

    breakBlock(block) {
        let doTileDrops;
        if (!this.dropLoot) {
            doTileDrops = world.gameRules.doTileDrops;
            world.gameRules.doTileDrops = false;
        }
        // eslint-disable-next-line minecraft-linting/avoid-unnecessary-command
        overworld.runCommand(`/setblock ${V3.fromBlock(block, false)} air destroy`);
        // Restore the original game rule value
        if (doTileDrops !== undefined) world.gameRules.doTileDrops = doTileDrops;
        this.block = null;
        this.broadcastSignal("onComplete");
    }

    constructor(...args){
        super(...args);
        this.block = null;
        this.blockLocation = null;
        this.blockTypeId = null;
        this.breakDuration = 0;
        this.dropLoot = true;
        this.blockBreakerEntity = null;
    }
}

BreakBlockStep.definition = {
    identifier: "step:break_block",
    priority: BreakBlockStepData.Priority
};
