import { LocationVar } from "BigBrain/Context/LocationVar";
import NavigateToTargetStepData from "Data/BigBrain/Steps/NavigateToTargetStepData";
import AbstractState from "StateSkeleton/States/AbstractState";

export class NavigateToTargetStep extends AbstractState {
    onEnter(_memory) {
        this.positionSamples = [];
        this.warmupStartTick = Main.currentTick;
    }

    onActiveTick() {
        if (Main.currentTick - this.warmupStartTick < NavigateToTargetStepData.WarmupDuration) return;
        if (this.activeTicks % NavigateToTargetStepData.PositionSampleInterval === 0) {
            this.samplePositionAndCheckIfStuck();
            this.checkLedgeAndLavaHazard();
        }
    }

    /**
     * Raycasts ahead of the companion to catch sheer drops, ravines, and lava pools
     */
    checkLedgeAndLavaHazard() {
        const entity = this.context.entity;
        if (!entity || !entity.isValid) return;

        const dim = entity.dimension;
        const loc = entity.location;
        const viewDir = entity.getViewDirection();

        // Check 1 block ahead in the walking direction
        const aheadX = Math.floor(loc.x + viewDir.x);
        const aheadZ = Math.floor(loc.z + viewDir.z);
        const footY = Math.floor(loc.y);

        const groundBlock = dim.getBlock({ x: aheadX, y: footY - 1, z: aheadZ });
        const dropBlock = dim.getBlock({ x: aheadX, y: footY - 2, z: aheadZ });
        const lavaCheck = dim.getBlock({ x: aheadX, y: footY, z: aheadZ });

        // Lava Hazard Detection
        const isLavaAhead = groundBlock?.typeId === "minecraft:lava" || 
                            dropBlock?.typeId === "minecraft:lava" || 
                            lavaCheck?.typeId === "minecraft:lava";

        // Cliff/Canyon Dropoff Detection (2+ block drop into air)
        const isSheerDrop = groundBlock?.isAir && dropBlock?.isAir;

        if (isLavaAhead || isSheerDrop) {
            // Force sneaking to stick to the ledge edge without slipping off
            entity.isSneaking = true;
            // Abort current forward trajectory to prevent falling
            this.onStuck();
        } else {
            // Restore normal posture if clear
            if (entity.isSneaking) {
                entity.isSneaking = false;
            }
        }
    }

    /**
     * Records the entity's current position and, once enough samples exist,
     * checks whether all recent positions are within a small radius of the oldest.
     * If so, the entity is considered stuck and the path is reset.
     */
    samplePositionAndCheckIfStuck() {
        const position = this.context.getValue(LocationVar).clone();
        this.positionSamples.push(position);

        // If not enough samples, return early
        if (this.positionSamples.length < NavigateToTargetStepData.PositionSampleSize) return;

        // Calculate the distances from the oldest position
        const oldestPosition = this.positionSamples.shift();
        const distances = [];
        for (const position of this.positionSamples) {
            distances.push(position.distance(oldestPosition));
        }
        const maxDistance = Math.max(...distances);

        // If the maximum distance is below the threshold and not in water, the entity is stuck
        const isSwimming = this.context.entity.getMobComponent("MovementComponent")?.isSwimming();
        if (maxDistance < NavigateToTargetStepData.StuckDistanceThreshold && !isSwimming) this.onStuck();
    }

    onStuck() {
        this.positionSamples = [];
        this.warmupStartTick = Main.currentTick;
        this.broadcastSignal("onStuck");
    }

    constructor(...args) {
        super(...args);
        /** Rolling window of recent positions used to detect if the entity is stuck */
        this.positionSamples = [];
        this.warmupStartTick = 0;
    }
}

NavigateToTargetStep.definition = {
    identifier: "step:navigate_to_target",
    priority: NavigateToTargetStepData.Priority
};
