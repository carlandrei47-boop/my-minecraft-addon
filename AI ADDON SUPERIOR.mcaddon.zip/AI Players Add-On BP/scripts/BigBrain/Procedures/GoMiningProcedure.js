import { LocationVar } from "BigBrain/Context/LocationVar";
import { NearestPlayerVar } from "BigBrain/Context/NearestPlayerVar";
import GoMiningProcedureData from "Data/BigBrain/Procedures/GoMiningProcedureData";
import FeatureCache from "FeatureCache/FeatureCache";
import V3 from "Helpers/Vectors/V3";
import InventoryHelper from "Inventory/InventoryHelper";
import CompositeState from "StateSkeleton/States/CompositeState";
import { GoMineVeinProcedure } from "./GoMineVeinProcedure";
import { MineBlockProcedure } from "./MineBlockProcedure";
import { PathToRandomPointProcedure } from "./PathToRandomPointProcedure";

const registry = [
    GoMineVeinProcedure,
    PathToRandomPointProcedure
];

export class GoMiningProcedure extends CompositeState {
    get currentTargetIsPrimary() {
        return this.currentTarget?.type === this.primaryFeatureType;
    }

    setMaxFeatureDistanceFromPlayer(distance) {
        this.maxFeatureDistanceFromPlayer = distance;
    }

    setCanRandomSearch(canSearch) {
        this.canRandomSearch = canSearch;
    }

    setPrimaryFeatureType(featureType) {
        this.primaryFeatureType = featureType;
        this.primaryNearestVar = GoMiningProcedureData.NearestVars[featureType];
        this.primaryReachableVar = GoMiningProcedureData.ReachableVars[featureType];
        const secondaryTypes = this.getSecondaryTypes();
        this.secondaryReachableVars = secondaryTypes.map((t) => GoMiningProcedureData.ReachableVars[t]);
    }

    getSecondaryTypes() {
        const secondaryTypes = GoMiningProcedureData.SecondaryVeins[this.primaryFeatureType] ?? [];
        return secondaryTypes.filter((secondaryType) => InventoryHelper.hasPickaxeForFeature(this.context.entity, secondaryType));
    }

    getCurrentFeatureTypes() {
        if (!this.primaryFeatureType) return [];
        return [
            this.primaryFeatureType,
            ...this.getSecondaryTypes()
        ];
    }

    onEnter(memory) {
        this.tryRestoreFromMemory(memory);
    }

    tryRestoreFromMemory(memory) {
        if (!memory?.targetId) return false;
        const feature = FeatureCache.getFeatureById(memory.targetId);
        if (!feature) return false;
        if (!FeatureCache.isFeatureValid(feature)) return false;
        if (FeatureCache.isFeatureLockedByOther(feature, this.context.entity.id)) return false;
        if (!this.isWithinMaxDistanceFromPlayer(feature)) return false;
        this.setVein(feature);
        return true;
    }

    createMemory() {
        if (!this.currentTarget) return undefined;
        return {
            targetId: this.currentTarget.id
        };
    }

    setCurrentTarget(feature) {
        const entityId = this.context.entity.id;
        if (this.currentTarget?.lockedBy === entityId) this.currentTarget.lockedBy = null;
        this.currentTarget = feature;
        if (feature) feature.lockedBy = entityId;
    }

    onExit() {
        this.setCurrentTarget(null);
    }

    onSubstateComplete(_state) {
        const completedTargetWasPrimary = this.currentTargetIsPrimary;
        this.setCurrentTarget(null);
        if (completedTargetWasPrimary) this.broadcastSignal("onComplete");
        else this.chooseNextVein();
    }

    onSubstateFailure() {
        this.setSubstate(null);
        this.broadcastSignal("onFailure");
    }

    onActiveTick() {
        // --- WATER DAM & LIQUID HAZARD INTERVENTION ---
        this.checkForWaterHazard();
        // ----------------------------------------------

        if (!this.currentTarget && !this.currentSubstate) {
            this.chooseNextVein();
            return;
        }
        if (this.currentTarget && FeatureCache.isFeatureLockedByOther(this.currentTarget, this.context.entity.id)) {
            this.onFeatureLockedByOther();
        }
        if (this.isMiningVein()) return;
        if (Main.currentTick - this.lastSwapCheckTick < GoMiningProcedureData.SwapCheckInterval) return;
        this.lastSwapCheckTick = Main.currentTick;
        if (this.currentSubstate?.is(PathToRandomPointProcedure)) this.tryExitRandomSearch();
        else this.trySwapToNearestReachable();
    }

    /**
     * Scans around the bot for water flooding into mining tunnels and seals the source
     */
    checkForWaterHazard() {
        const entity = this.context.entity;
        if (!entity || !entity.isValid) return;

        const dim = entity.dimension;
        const loc = entity.location;
        const checkOffsets = [
            { x: 0, y: 1, z: 0 },
            { x: 1, y: 0, z: 0 },
            { x: -1, y: 0, z: 0 },
            { x: 0, y: 0, z: 1 },
            { x: 0, y: 0, z: -1 },
            { x: 0, y: 2, z: 0 }
        ];

        for (const off of checkOffsets) {
            const checkLoc = {
                x: Math.floor(loc.x + off.x),
                y: Math.floor(loc.y + off.y),
                z: Math.floor(loc.z + off.z)
            };
            const block = dim.getBlock(checkLoc);
            if (block?.typeId === "minecraft:water" || block?.typeId === "minecraft:flowing_water") {
                // Plug the water stream with cobblestone to prevent drowning / washing away
                try {
                    block.setType("minecraft:cobblestone");
                } catch {
                    // Fallback if unable to set
                }
                break;
            }
        }
    }

    onFeatureLockedByOther() {
        this.setCurrentTarget(null);
        this.chooseNextVein();
    }

    chooseNextVein() {
        const next = this.getNearestReachable() ?? this.getNearestPrimaryFeature();
        if (next) {
            this.setVein(next);
            this.lastSwapCheckTick = Main.currentTick;
            return;
        }
        if (this.canRandomSearch) return this.enterRandomSearch();
        this.setSubstate(null);
        return this.broadcastSignal("onFailure");
    }

    isWithinMaxDistanceFromPlayer(feature) {
        if (this.maxFeatureDistanceFromPlayer === null) return true;
        const nearestPlayer = this.context.getValue(NearestPlayerVar);
        if (!nearestPlayer) return true;
        const playerLocation = V3.fromEntity(nearestPlayer.entity, overworld);
        const featureRoot = feature.root;
        return playerLocation.distance(featureRoot) <= this.maxFeatureDistanceFromPlayer;
    }

    enterRandomSearch() {
        const pathToRandomPoint = this.getSubstate(PathToRandomPointProcedure);
        
        // Target Y = -58 bias when mining high-tier ores like Diamond
        const isDiamondGoal = this.primaryFeatureType?.includes("diamond");
        const entityLoc = this.context.getValue(LocationVar);

        if (isDiamondGoal && entityLoc && entityLoc.y > -50) {
            // Bias volume downwards toward deepslate levels
            pathToRandomPoint.setSearchVolume(new V3(16, -30, 16));
        } else {
            pathToRandomPoint.setSearchVolume(GoMiningProcedureData.RandomSearchVolume);
        }

        pathToRandomPoint.setOffsetInViewDirection(GoMiningProcedureData.RandomOffsetInViewDirection);
        pathToRandomPoint.setOnSurfaceOnly(false);
        this.setSubstate(pathToRandomPoint);
        this.broadcastSignal("onSearch");
    }

    tryExitRandomSearch() {
        const next = this.getNearestReachable() ?? this.getNearestPrimaryFeature();
        if (!next) return;
        this.setVein(next);
        this.lastSwapCheckTick = Main.currentTick;
    }

    trySwapToNearestReachable() {
        if (!this.currentTarget) return;
        const nearest = this.getNearestReachable();
        if (!nearest || nearest === this.currentTarget) return;
        this.setVein(nearest);
    }

    setVein(feature) {
        if (!this.isWithinMaxDistanceFromPlayer(feature)) return this.broadcastSignal("onFailure");
        this.setCurrentTarget(feature);
        const goMineVeinProcedure = this.getSubstate(GoMineVeinProcedure);
        goMineVeinProcedure.setTargetVein(feature);
        this.setSubstate(goMineVeinProcedure);
    }

    getReachableFeatures(varId) {
        if (!varId) return [];
        return this.context.getValue(varId)?.features ?? [];
    }

    getAllReachableFeatures() {
        const allVars = [
            this.primaryReachableVar,
            ...this.secondaryReachableVars
        ];
        return allVars.flatMap((varId) => this.getReachableFeatures(varId));
    }

    getNearestReachable() {
        const entityRoot = this.context.getValue(LocationVar);
        let best = null;
        for (const feature of this.getAllReachableFeatures()) {
            const distance = entityRoot.distance(feature.root);
            if (best && distance >= best.distance) continue;
            best = {
                object: feature,
                distance
            };
        }
        return best?.object ?? null;
    }

    getNearestPrimaryFeature() {
        if (!this.primaryNearestVar) return null;
        return this.context.getValue(this.primaryNearestVar)?.feature ?? null;
    }

    isMiningVein() {
        const substate = this.currentSubstate;
        if (substate?.is(GoMineVeinProcedure) && substate.currentSubstate?.is(MineBlockProcedure)) return true;
        return false;
    }

    constructor(...args) {
        super(...args);
        this.secondaryReachableVars = [];
        this.currentTarget = null;
        this.lastSwapCheckTick = 0;
        this.maxFeatureDistanceFromPlayer = null;
        this.canRandomSearch = true;
    }
}

GoMiningProcedure.definition = {
    identifier: "procedure:go_mining",
    priority: GoMiningProcedureData.Priority,
    registry,
    initialState: null
};
