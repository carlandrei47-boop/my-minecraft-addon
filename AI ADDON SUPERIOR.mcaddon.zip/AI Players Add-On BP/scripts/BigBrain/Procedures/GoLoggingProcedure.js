import { LocationVar } from "BigBrain/Context/LocationVar";
import { NearestTreeFeatureVar } from "BigBrain/Context/NearestFeature/NearestTreeFeatureVar";
import { NearestPlayerVar } from "BigBrain/Context/NearestPlayerVar";
import { PillarBlockLocationsVar } from "BigBrain/Context/PillarBlockLocationsVar";
import GoLoggingProcedureData from "Data/BigBrain/Procedures/GoLoggingProcedureData";
import FeatureCache from "FeatureCache/FeatureCache";
import { createCachedProxy } from "Helpers/CachedProxy";
import V3 from "Helpers/Vectors/V3";
import CompositeState from "StateSkeleton/States/CompositeState";
import BlockUtils from "Utils/BlockUtils";
import { GoMineVeinProcedure } from "./GoMineVeinProcedure";
import { MineBlocksProcedure } from "./MineBlocksProcedure";
import { PathToNodeProcedure } from "./PathToNodeProcedure";
import { PathToRandomPointProcedure } from "./PathToRandomPointProcedure";

const registry = [
    GoMineVeinProcedure,
    MineBlocksProcedure,
    PathToRandomPointProcedure
];

export class GoLoggingProcedure extends CompositeState {
    setMaxFeatureDistanceFromPlayer(distance) {
        this.maxFeatureDistanceFromPlayer = distance;
    }

    setCanRandomSearch(canSearch) {
        this.canRandomSearch = canSearch;
    }

    onEnter(memory) {
        this.tryRestoreFromMemory(memory);
    }

    getRelevantFeatureTypes() {
        return [
            "tree"
        ];
    }

    tryRestoreFromMemory(memory) {
        if (!memory?.targetId) return false;
        const feature = FeatureCache.getFeatureById(memory.targetId);
        if (!feature) return false;
        if (!FeatureCache.isFeatureValid(feature)) return false;
        if (FeatureCache.isFeatureLockedByOther(feature, this.context.entity.id)) return false;
        if (!this.isWithinMaxDistanceFromPlayer(feature)) return false;
        this.setVein(feature);
        return true;
    }

    createMemory() {
        if (!this.currentTarget) return undefined;
        return {
            targetId: this.currentTarget.id
        };
    }

    setCurrentTarget(feature) {
        const entityId = this.context.entity.id;
        if (this.currentTarget?.lockedBy === entityId) this.currentTarget.lockedBy = null;
        this.currentTarget = feature;
        if (feature) feature.lockedBy = entityId;
    }

    onExit() {
        this.setCurrentTarget(null);
    }

    onSubstateComplete(_state) {
        if (_state.is(GoMineVeinProcedure)) {
            this.scanAndClearFullTrunk();
            this.tryCleanUpPillarBlocks();
        } else if (_state.is(MineBlocksProcedure)) {
            this.replantSaplingAtBase();
            this.setCurrentTarget(null);
            this.broadcastSignal("onComplete");
        }
    }

    /**
     * Prevents floating canopies: verifies vertical trunk clearance up to 16 blocks high
     */
    scanAndClearFullTrunk() {
        if (!this.currentTarget?.root) return;
        const dim = this.context.entity.dimension;
        const root = this.currentTarget.root;
        const pillarList = this.context.getValue(PillarBlockLocationsVar) ?? [];

        for (let yOffset = 1; yOffset <= 16; yOffset++) {
            const checkLoc = { x: Math.floor(root.x), y: Math.floor(root.y) + yOffset, z: Math.floor(root.z) };
            const blk = dim.getBlock(checkLoc);
            if (blk && blk.typeId.includes("log")) {
                // If higher than reach, pillar up and queue breaking
                try {
                    dim.runCommand(`setblock ${checkLoc.x} ${checkLoc.y - 1} ${checkLoc.z} dirt keep`);
                    pillarList.push(new V3(checkLoc.x, checkLoc.y - 1, checkLoc.z));
                    blk.setType("minecraft:air");
                } catch {
                    // Fallback
                }
            }
        }
    }

    /**
     * Replants appropriate sapling when tree harvest is finished
     */
    replantSaplingAtBase() {
        if (!this.currentTarget?.root) return;
        const dim = this.context.entity.dimension;
        const root = this.currentTarget.root;
        const baseLoc = { x: Math.floor(root.x), y: Math.floor(root.y), z: Math.floor(root.z) };
        const ground = dim.getBlock({ x: baseLoc.x, y: baseLoc.y - 1, z: baseLoc.z });

        if (ground && (ground.typeId === "minecraft:dirt" || ground.typeId === "minecraft:grass_block")) {
            const spot = dim.getBlock(baseLoc);
            if (spot && spot.isAir) {
                try {
                    spot.setType("minecraft:oak_sapling");
                } catch {
                    // Ignore if obstructed
                }
            }
        }
    }

    onSubstateFailure() {
        this.setSubstate(null);
        this.broadcastSignal("onFailure");
    }

    onActiveTick() {
        if (!this.currentTarget && !this.currentSubstate) {
            this.chooseNextVein();
            return;
        }
        if (this.currentTarget && FeatureCache.isFeatureLockedByOther(this.currentTarget, this.context.entity.id)) {
            this.onFeatureLockedByOther();
        }
        if (Main.currentTick - this.lastSwapCheckTick < GoLoggingProcedureData.SwapCheckInterval) return;
        this.lastSwapCheckTick = Main.currentTick;
        if (this.currentSubstate?.is(PathToRandomPointProcedure)) {
            this.tryExitRandomSearch();
            return;
        }
        const isInGoMineVein = this.currentSubstate?.is(GoMineVeinProcedure);
        const isInPathToNode = this.currentSubstate?.currentSubstate?.is(PathToNodeProcedure);
        if (isInGoMineVein && isInPathToNode) this.trySwapToNearerTree();
    }

    tryCleanUpPillarBlocks() {
        const mineBlocksProcedure = this.getSubstate(MineBlocksProcedure);
        mineBlocksProcedure.setBlocks(this.getPillarBlocksToMine());
        mineBlocksProcedure.setCanPlaceBlocks(false);
        this.context.getValue(PillarBlockLocationsVar).length = 0;
        this.setSubstate(mineBlocksProcedure);
    }

    onFeatureLockedByOther() {
        this.setCurrentTarget(null);
        this.chooseNextVein();
    }

    chooseNextVein() {
        const nearest = this.context.getValue(NearestTreeFeatureVar.identifier)?.feature ?? null;
        if (nearest) {
            this.setVein(nearest);
            this.lastSwapCheckTick = Main.currentTick;
            return;
        }
        if (this.canRandomSearch) return this.enterRandomSearch();
        this.setSubstate(null);
        this.broadcastSignal("onFailure");
    }

    enterRandomSearch() {
        const pathToRandomPoint = this.getSubstate(PathToRandomPointProcedure);
        pathToRandomPoint.setSearchVolume(GoLoggingProcedureData.RandomSearchVolume);
        pathToRandomPoint.setOffsetInViewDirection(GoLoggingProcedureData.RandomOffsetInViewDirection);
        pathToRandomPoint.setOnSurfaceOnly(true);
        this.setSubstate(pathToRandomPoint);
        this.broadcastSignal("onSearch");
    }

    tryExitRandomSearch() {
        const nearest = this.context.getValue(NearestTreeFeatureVar.identifier)?.feature ?? null;
        if (!nearest) return;
        this.setVein(nearest);
        this.lastSwapCheckTick = Main.currentTick;
    }

    isWithinMaxDistanceFromPlayer(feature) {
        if (this.maxFeatureDistanceFromPlayer === null) return true;
        const nearestPlayer = this.context.getValue(NearestPlayerVar);
        if (!nearestPlayer) return true;
        const playerLocation = V3.fromEntity(nearestPlayer.entity, overworld);
        const featureRoot = feature.root;
        return playerLocation.distance(featureRoot) <= this.maxFeatureDistanceFromPlayer;
    }

    trySwapToNearerTree() {
        if (!this.currentTarget) return;
        const nearest = this.context.getValue(NearestTreeFeatureVar.identifier)?.feature ?? null;
        if (!nearest || nearest === this.currentTarget) return;
        const entityRoot = this.context.getValue(LocationVar);
        const currentDistance = entityRoot.distance(this.currentTarget.root);
        const nearestDistance = entityRoot.distance(nearest.root);
        if (nearestDistance >= currentDistance) return;
        this.setVein(nearest);
    }

    setVein(feature) {
        if (!this.isWithinMaxDistanceFromPlayer(feature)) {
            return this.broadcastSignal("onFailure");
        }
        this.setCurrentTarget(feature);
        const goMineVeinProcedure = this.getSubstate(GoMineVeinProcedure);
        goMineVeinProcedure.setTargetVein(feature);
        this.setSubstate(goMineVeinProcedure);
    }

    getPillarBlocksToMine() {
        const locations = this.context.getValue(PillarBlockLocationsVar) ?? [];
        const blocks = [];
        for (const location of locations) {
            let block = BlockUtils.fromV3(location);
            if (!block) continue;
            block = createCachedProxy(block, new Map(Object.entries({
                location
            })));
            blocks.push(block);
        }
        return blocks;
    }

    constructor(...args) {
        super(...args);
        this.currentTarget = null;
        this.lastSwapCheckTick = 0;
        this.maxFeatureDistanceFromPlayer = null;
        this.canRandomSearch = true;
    }
}

GoLoggingProcedure.definition = {
    identifier: "procedure:go_logging",
    priority: GoLoggingProcedureData.Priority,
    registry,
    initialState: null
};
