import { world, system } from "@minecraft/server";
import CompositeState from "StateSkeleton/States/CompositeState";
import { BaseGuard } from "../../Utils/BaseGuard.js";

export class BuildHomeProcedure extends CompositeState {
    onActiveTick() {
        const bot = this.context.entity;
        if (!bot?.isValid) return;

        const dim = bot.dimension;
        if (dim.id !== "minecraft:overworld") return;

        // Run check every 5 seconds (100 ticks)
        if (Main.currentTick % 100 !== 0) return;

        // 1. Strict Nomad Check: Never build unless explicitly given the settle command
        // Ignores player beds and temporary camps completely
        const canSettle = bot.hasTag("order:settle");
        if (!canSettle) return;

        // 2. Village Buffer: Never build directly inside or near villages (within 48 blocks)
        if (this.isNearVillage(bot, dim)) return;

        // 3. Skip if already assigned a home base
        const hasHome = bot.getTags().some(t => t.startsWith("home_loc:") || t.startsWith("bed_loc:"));
        if (hasHome || BaseGuard.isInsideProtectedZone(bot.location, dim)) return;

        // Build only during daytime
        const timeOfDay = world.getTimeOfDay();
        if (timeOfDay > 11000 && timeOfDay < 23000) return;

        // Requires 32 planks or cobblestone
        if (!this.hasBuildingSupplies(bot)) return;

        const plot = this.findBuildPlot(bot, dim);
        if (!plot) return;

        this.constructStarterCabin(bot, dim, plot);
        bot.removeTag("order:settle"); // Consume command after construction
    }

    isNearVillage(bot, dim) {
        const nearbyVillagers = dim.getEntities({
            location: bot.location,
            maxDistance: 48,
            families: ["villager", "iron_golem"]
        });
        return nearbyVillagers.length > 0;
    }

    hasBuildingSupplies(bot) {
        const inv = bot.getComponent("minecraft:inventory")?.container;
        if (!inv) return false;

        let blockCount = 0;
        for (let i = 0; i < inv.size; i++) {
            const item = inv.getItem(i);
            if (!item) continue;
            if (item.typeId.includes("planks") || item.typeId.includes("cobblestone")) {
                blockCount += item.amount;
            }
        }
        return blockCount >= 32;
    }

    findBuildPlot(bot, dim) {
        const loc = bot.location;
        const originX = Math.floor(loc.x);
        const originY = Math.floor(loc.y);
        const originZ = Math.floor(loc.z);

        for (let dx = 3; dx <= 7; dx++) {
            for (let dz = 3; dz <= 7; dz++) {
                const checkX = originX + dx;
                const checkZ = originZ + dz;
                const groundBlock = dim.getBlock({ x: checkX, y: originY - 1, z: checkZ });
                const air1 = dim.getBlock({ x: checkX, y: originY, z: checkZ });
                const air2 = dim.getBlock({ x: checkX, y: originY + 1, z: checkZ });

                if (groundBlock?.isSolid && air1?.isAir && air2?.isAir) {
                    return { x: checkX, y: originY, z: checkZ };
                }
            }
        }
        return null;
    }

    constructStarterCabin(bot, dim, plot) {
        const { x, y, z } = plot;

        // Interior clearance
        dim.runCommand(`fill ${x} ${y} ${z} ${x + 4} ${y + 3} ${z + 4} air`);
        // Floor
        dim.runCommand(`fill ${x} ${y - 1} ${z} ${x + 4} ${y - 1} ${z + 4} cobblestone`);
        // Outer walls
        dim.runCommand(`fill ${x} ${y} ${z} ${x + 4} ${y + 2} ${z + 4} oak_planks outline`);
        // Roof
        dim.runCommand(`fill ${x} ${y + 3} ${z} ${x + 4} ${y + 3} ${z + 4} oak_planks`);

        // Doorway & Door
        dim.runCommand(`setblock ${x + 2} ${y} ${z} air`);
        dim.runCommand(`setblock ${x + 2} ${y + 1} ${z} air`);
        dim.runCommand(`setblock ${x + 2} ${y} ${z} wooden_door [direction=0]`);

        // Windows
        dim.runCommand(`setblock ${x} ${y + 1} ${z + 2} glass`);
        dim.runCommand(`setblock ${x + 4} ${y + 1} ${z + 2} glass`);

        // Interior Workstations
        dim.runCommand(`setblock ${x + 1} ${y} ${z + 3} crafting_table`);
        dim.runCommand(`setblock ${x + 3} ${y} ${z + 3} chest [facing_direction=2]`);
        dim.runCommand(`setblock ${x + 2} ${y + 2} ${z + 2} torch [torch_facing_direction=top]`);

        this.consumeBuildingSupplies(bot, 32);
        bot.addTag(`home_loc:${x + 2}:${y}:${z + 2}`);
    }

    consumeBuildingSupplies(bot, count) {
        const inv = bot.getComponent("minecraft:inventory")?.container;
        if (!inv) return;

        let needed = count;
        for (let i = 0; i < inv.size; i++) {
            if (needed <= 0) break;
            const item = inv.getItem(i);
            if (!item) continue;

            if (item.typeId.includes("planks") || item.typeId.includes("cobblestone")) {
                if (item.amount <= needed) {
                    needed -= item.amount;
                    inv.setItem(i, undefined);
                } else {
                    item.amount -= needed;
                    needed = 0;
                    inv.setItem(i, item);
                }
            }
        }
    }
}

BuildHomeProcedure.definition = {
    identifier: "procedure:build_home",
    priority: 120,
    registry: [],
    initialState: null
};
