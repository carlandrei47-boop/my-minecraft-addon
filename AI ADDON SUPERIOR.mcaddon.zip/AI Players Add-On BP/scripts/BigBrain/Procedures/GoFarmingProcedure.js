import { world, system, ItemStack } from "@minecraft/server";
import CompositeState from "StateSkeleton/States/CompositeState";
import V3 from "Helpers/Vectors/V3";

const HARVESTABLE_CROPS = {
    "minecraft:wheat": 7,
    "minecraft:carrots": 7,
    "minecraft:potatoes": 7,
    "minecraft:beetroot": 7,
    "minecraft:sweet_berry_bush": 3,
    "minecraft:cocoa": 2
};

export class GoFarmingProcedure extends CompositeState {
    onActiveTick() {
        const bot = this.context.entity;
        if (!bot?.isValid) return;

        const dim = bot.dimension;
        const currentBlock = dim.getBlock(bot.location);
        const blockBelow = dim.getBlock({
            x: Math.floor(bot.location.x),
            y: Math.floor(bot.location.y) - 1,
            z: Math.floor(bot.location.z)
        });

        // 1. Anti-Trample: Force sneaking over farmland to protect crops
        if (blockBelow?.typeId === "minecraft:farmland" || currentBlock?.typeId === "minecraft:farmland") {
            bot.isSneaking = true;
        } else if (bot.isSneaking) {
            bot.isSneaking = false;
        }

        if (Main.currentTick % 20 !== 0) return;

        // 2. Auto-craft scaffolding if holding bamboo and string
        this.tryCraftScaffolding(bot);

        // 3. Scan 9x9 perimeter around bot (radius 4)
        const center = bot.location;
        for (let dx = -4; dx <= 4; dx++) {
            for (let dz = -4; dz <= 4; dz++) {
                for (let dy = -1; dy <= 4; dy++) {
                    const checkPos = {
                        x: Math.floor(center.x) + dx,
                        y: Math.floor(center.y) + dy,
                        z: Math.floor(center.z) + dz
                    };

                    const block = dim.getBlock(checkPos);
                    if (!block || block.isAir) continue;

                    // Sustainable Bamboo & Sugarcane Harvest (leaves base stalk intact)
                    if (block.typeId === "minecraft:bamboo" || block.typeId === "minecraft:sugar_cane") {
                        const below = dim.getBlock({ x: checkPos.x, y: checkPos.y - 1, z: checkPos.z });
                        if (below?.typeId === block.typeId) {
                            dim.runCommand(`setblock ${checkPos.x} ${checkPos.y} ${checkPos.z} air destroy`);
                            return;
                        }
                    }

                    // Melons and Pumpkins
                    if (block.typeId === "minecraft:melon_block" || block.typeId === "minecraft:pumpkin") {
                        dim.runCommand(`setblock ${checkPos.x} ${checkPos.y} ${checkPos.z} air destroy`);
                        return;
                    }

                    // Age-based crops (auto-replant immediately)
                    const maxAge = HARVESTABLE_CROPS[block.typeId];
                    if (maxAge !== undefined) {
                        const growth = block.permutation.getState("growth") ?? block.permutation.getState("age");
                        if (growth >= maxAge) {
                            const replantType = block.typeId;
                            dim.runCommand(`setblock ${checkPos.x} ${checkPos.y} ${checkPos.z} air destroy`);
                            system.runTimeout(() => {
                                try {
                                    dim.runCommand(`setblock ${checkPos.x} ${checkPos.y} ${checkPos.z} ${replantType}`);
                                } catch {}
                            }, 5);
                            return;
                        }
                    }

                    // Beehives & Bee Nests (harvests only if campfire is lit underneath)
                    if (block.typeId === "minecraft:beehive" || block.typeId === "minecraft:bee_nest") {
                        const underBlock = dim.getBlock({ x: checkPos.x, y: checkPos.y - 1, z: checkPos.z });
                        const underTwo = dim.getBlock({ x: checkPos.x, y: checkPos.y - 2, z: checkPos.z });
                        const isSmoked = underBlock?.typeId.includes("campfire") || underTwo?.typeId.includes("campfire");

                        const honeyLevel = block.permutation.getState("honey_level");
                        if (honeyLevel === 5 && isSmoked) {
                            dim.spawnItem(new ItemStack("minecraft:honey_bottle", 1), checkPos);
                            dim.runCommand(`setblock ${checkPos.x} ${checkPos.y} ${checkPos.z} ${block.typeId} [honey_level=0]`);
                            return;
                        }
                    }
                }
            }
        }
    }

    /**
     * Converts 6 Bamboo + 1 String into 6 Scaffolding blocks
     */
    tryCraftScaffolding(bot) {
        const inv = bot.getComponent("minecraft:inventory")?.container;
        if (!inv) return;

        let bambooSlot = -1;
        let stringSlot = -1;

        for (let i = 0; i < inv.size; i++) {
            const item = inv.getItem(i);
            if (!item) continue;
            if (item.typeId === "minecraft:bamboo" && item.amount >= 6) bambooSlot = i;
            if (item.typeId === "minecraft:string" && item.amount >= 1) stringSlot = i;
        }

        if (bambooSlot !== -1 && stringSlot !== -1) {
            const bambooItem = inv.getItem(bambooSlot);
            const stringItem = inv.getItem(stringSlot);

            if (bambooItem.amount === 6) inv.setItem(bambooSlot, undefined);
            else { bambooItem.amount -= 6; inv.setItem(bambooSlot, bambooItem); }

            if (stringItem.amount === 1) inv.setItem(stringSlot, undefined);
            else { stringItem.amount -= 1; inv.setItem(stringSlot, stringItem); }

            inv.addItem(new ItemStack("minecraft:scaffolding", 6));
        }
    }

    /**
     * Creates a hydrated 9x9 farmland plot centered around water
     */
    static createStandardPlot(centerLoc, dimension) {
        const cx = Math.floor(centerLoc.x);
        const cy = Math.floor(centerLoc.y);
        const cz = Math.floor(centerLoc.z);

        dimension.runCommand(`setblock ${cx} ${cy} ${cz} water`);

        for (let dx = -4; dx <= 4; dx++) {
            for (let dz = -4; dz <= 4; dz++) {
                if (dx === 0 && dz === 0) continue;
                const plotPos = { x: cx + dx, y: cy, z: cz + dz };
                dimension.runCommand(`setblock ${plotPos.x} ${plotPos.y} ${plotPos.z} farmland`);
            }
        }
    }
}

GoFarmingProcedure.definition = {
    identifier: "procedure:go_farming",
    priority: 120,
    registry: [],
    initialState: null
};
