import { world, system } from "@minecraft/server";
import CompositeState from "StateSkeleton/States/CompositeState";
import { BaseGuard } from "../../Utils/BaseGuard.js";

export class NightSurvivalProcedure extends CompositeState {
    onActiveTick() {
        const bot = this.context.entity;
        if (!bot?.isValid) return;

        const dim = bot.dimension;
        if (dim.id !== "minecraft:overworld") return;

        if (Main.currentTick % 40 !== 0) return;

        const timeOfDay = world.getTimeOfDay();
        const isNight = timeOfDay >= 12500 && timeOfDay <= 23500;
        const isMorning = timeOfDay >= 0 && timeOfDay <= 2000;

        const shelterTag = bot.getTags().find(t => t.startsWith("mole_shaft:"));

        // MORNING ROUTINE: Uncap roof and clear shelter tag
        if (isMorning) {
            if (shelterTag) {
                const [, x, y, z] = shelterTag.split(":").map(Number);
                dim.runCommand(`setblock ${x} ${y} ${z} air destroy`);
                bot.removeTag(shelterTag);
            }
            return;
        }

        // NIGHTFALL ROUTINE
        if (isNight && !shelterTag) {
            // 1. If assigned to a base or within a safe zone, let native pathfinding take them to their permanent bed
            const hasAssignedHome = bot.getTags().some(t => 
                t.startsWith("home_loc:") || 
                t.startsWith("bed_loc:") || 
                t.includes("assigned_bed")
            );
            const insideSafeZone = BaseGuard.isInsideProtectedZone(bot.location, dim);

            if (hasAssignedHome || insideSafeZone) {
                return;
            }

            // 2. Wilderness Priority A: Use temporary straw roll if wheat/hay/straw is present
            if (this.tryDeployStrawRoll(bot, dim)) {
                return;
            }

            // 3. Wilderness Priority B: Dig clean mole shaft and cap roof
            this.executeMoleShaft(bot, dim);
        }
    }

    tryDeployStrawRoll(bot, dim) {
        const inv = bot.getComponent("minecraft:inventory")?.container;
        if (!inv) return false;

        let hasStrawMat = false;

        for (let i = 0; i < inv.size; i++) {
            const item = inv.getItem(i);
            if (!item) continue;
            // Matches hay/straw bed, sleeping bag, or raw hay materials
            if (item.typeId.includes("sleeping_bag") || item.typeId.includes("straw") || (item.typeId === "minecraft:hay_block" && item.amount >= 1)) {
                hasStrawMat = true;
                break;
            }
        }

        if (hasStrawMat) {
            bot.playAnimation("animation.player.sleeping", { blendOutTime: 0.5 });
            return true;
        }

        return false;
    }

    executeMoleShaft(bot, dim) {
        const loc = bot.location;
        const x = Math.floor(loc.x);
        const y = Math.floor(loc.y);
        const z = Math.floor(loc.z);

        // Dig a clean 3-block vertical shaft
        dim.runCommand(`setblock ${x} ${y - 1} ${z} air destroy`);
        dim.runCommand(`setblock ${x} ${y - 2} ${z} air destroy`);
        dim.runCommand(`setblock ${x} ${y - 3} ${z} air destroy`);

        bot.teleport({ x: x + 0.5, y: y - 3, z: z + 0.5 }, { dimension: dim });

        // Cap ONLY the roof entrance
        system.runTimeout(() => {
            dim.runCommand(`setblock ${x} ${y} ${z} dirt keep`);
            bot.addTag(`mole_shaft:${x}:${y}:${z}`);
        }, 5);
    }
}

NightSurvivalProcedure.definition = {
    identifier: "procedure:night_survival",
    priority: 150,
    registry: [],
    initialState: null
};
