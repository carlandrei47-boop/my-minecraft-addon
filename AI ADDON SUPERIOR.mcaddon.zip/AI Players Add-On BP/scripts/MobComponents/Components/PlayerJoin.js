import { system, world, ItemStack } from "@minecraft/server";
import V3 from "Helpers/Vectors/V3";
import { MobComponentPlayer } from "../AbstractMobComponent";

class PlayerJoin extends MobComponentPlayer {
    onJoin() {
        const player = this.entity;
        
        // Always run initialization to ensure tool is granted
        this.initialize(player);
        
        CustomEvents.emit("PlayerJoined", player);
        this.setupDimensionTether(player);
    }

    initialize(player) {
        // Use a short timeout to ensure the player's inventory container is ready in the world
        system.runTimeout(() => {
            if (!player || !player.isValid()) return;
            
            const inventory = player.getComponent("minecraft:inventory")?.container;
            if (!inventory) return;

            let hasTool = false;
            for (let i = 0; i < inventory.size; i++) {
                const item = inventory.getItem(i);
                if (item && item.typeId === "gm1_sky:admin_tool") {
                    hasTool = true;
                    break;
                }
            }

            if (!hasTool) {
                const adminTool = new ItemStack("gm1_sky:admin_tool", 1);
                adminTool.nameTag = "§bAI Manager Admin Panel";
                inventory.addItem(adminTool);
            }
        }, 10); // 10 ticks delay ensures container is fully initialized on join

        EntityStore.set(player, "PlayerInitialized", true);
    }

    setupDimensionTether(player) {
        // Teleports bot across portals into Nether / End / Overworld
        world.afterEvents.playerDimensionChange.subscribe((event) => {
            if (event.player.id !== player.id) return;

            system.runTimeout(() => {
                const targetDimension = event.toDimension;
                const fromDimension = event.fromDimension;

                const bots = fromDimension.getEntities({ type: "gm1_sky:aip" });
                for (const bot of bots) {
                    const teleportPos = {
                        x: Math.floor(player.location.x) + 1,
                        y: Math.floor(player.location.y),
                        z: Math.floor(player.location.z) + 1
                    };
                    bot.teleport(teleportPos, { dimension: targetDimension });
                }
            }, 40); // 2-second buffer to let destination chunks load
        });
    }

    constructor(entity) {
        super(entity, 5);
        this.onJoin();
    }
}

export { PlayerJoin as default };
