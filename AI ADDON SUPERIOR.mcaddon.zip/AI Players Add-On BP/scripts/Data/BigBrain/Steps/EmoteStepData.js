class EmoteStepData {
}
EmoteStepData.Priority = 0;
/**
     * Emote lengths in seconds from gm1_sky_aiplayer_emotes.ca.json.
     * Keys match gm1_sky:is_emoting values.
     */ EmoteStepData.EmoteDurationSecondsByIndex = {
    1: 1.125,
    2: 1.125,
    3: 1.125,
    4: 2.2,
    5: 5.3333,
    6: 5.5,
    7: 2.4583
};
/**
     * Localization keys for emotes.
     * Keys match gm1_sky:is_emoting values.
     */ EmoteStepData.EmoteLocKeysByIndex = {
    1: "gm1_sky.emote.wave",
    2: "gm1_sky.emote.wave",
    3: "gm1_sky.emote.wave",
    4: "gm1_sky.emote.clap",
    5: "gm1_sky.emote.dance",
    6: "gm1_sky.emote.dance",
    7: "gm1_sky.emote.dance"
};
export { EmoteStepData as default };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkVtb3RlU3RlcERhdGEudHMiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGRlZmF1bHQgY2xhc3MgRW1vdGVTdGVwRGF0YSB7XHJcbiAgICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IFByaW9yaXR5ID0gMDtcclxuXHJcbiAgICAvKipcclxuICAgICAqIEVtb3RlIGxlbmd0aHMgaW4gc2Vjb25kcyBmcm9tIGdtMV9za3lfYWlwbGF5ZXJfZW1vdGVzLmNhLmpzb24uXHJcbiAgICAgKiBLZXlzIG1hdGNoIGdtMV9za3k6aXNfZW1vdGluZyB2YWx1ZXMuXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgRW1vdGVEdXJhdGlvblNlY29uZHNCeUluZGV4OiBSZWNvcmQ8bnVtYmVyLCBudW1iZXI+ID0ge1xyXG4gICAgICAgIDE6IDEuMTI1LCAvL3dhdmVfbGVmdFxyXG4gICAgICAgIDI6IDEuMTI1LCAvL3dhdmVfcmlnaHRcclxuICAgICAgICAzOiAxLjEyNSwgLy93YXZlX2JvdGhcclxuICAgICAgICA0OiAyLjIsIC8vY2xhcFxyXG4gICAgICAgIDU6IDUuMzMzMywgLy9kYW5jZV8xXHJcbiAgICAgICAgNjogNS41LCAvL2RhbmNlXzJcclxuICAgICAgICA3OiAyLjQ1ODMsIC8vZGFuY2VfY29uZ2FcclxuICAgIH07XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBMb2NhbGl6YXRpb24ga2V5cyBmb3IgZW1vdGVzLlxyXG4gICAgICogS2V5cyBtYXRjaCBnbTFfc2t5OmlzX2Vtb3RpbmcgdmFsdWVzLlxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEVtb3RlTG9jS2V5c0J5SW5kZXg6IFJlY29yZDxudW1iZXIsIHN0cmluZz4gPSB7XHJcbiAgICAgICAgMTogXCJnbTFfc2t5LmVtb3RlLndhdmVcIixcclxuICAgICAgICAyOiBcImdtMV9za3kuZW1vdGUud2F2ZVwiLFxyXG4gICAgICAgIDM6IFwiZ20xX3NreS5lbW90ZS53YXZlXCIsXHJcbiAgICAgICAgNDogXCJnbTFfc2t5LmVtb3RlLmNsYXBcIixcclxuICAgICAgICA1OiBcImdtMV9za3kuZW1vdGUuZGFuY2VcIixcclxuICAgICAgICA2OiBcImdtMV9za3kuZW1vdGUuZGFuY2VcIixcclxuICAgICAgICA3OiBcImdtMV9za3kuZW1vdGUuZGFuY2VcIixcclxuICAgIH07XHJcbn1cclxuIl0sIm5hbWVzIjpbIkVtb3RlU3RlcERhdGEiLCJQcmlvcml0eSIsIkVtb3RlRHVyYXRpb25TZWNvbmRzQnlJbmRleCIsIkVtb3RlTG9jS2V5c0J5SW5kZXgiXSwibWFwcGluZ3MiOiJBQUFlLE1BQU1BO0FBOEJyQjtBQTlCcUJBLGNBQ01DLFdBQVc7QUFFbEM7OztLQUdDLEdBTmdCRCxjQU9NRSw4QkFBc0Q7SUFDekUsR0FBRztJQUNILEdBQUc7SUFDSCxHQUFHO0lBQ0gsR0FBRztJQUNILEdBQUc7SUFDSCxHQUFHO0lBQ0gsR0FBRztBQUNQO0FBRUE7OztLQUdDLEdBcEJnQkYsY0FxQk1HLHNCQUE4QztJQUNqRSxHQUFHO0lBQ0gsR0FBRztJQUNILEdBQUc7SUFDSCxHQUFHO0lBQ0gsR0FBRztJQUNILEdBQUc7SUFDSCxHQUFHO0FBQ1A7QUE3QkosU0FBcUJILDJCQThCcEIifQ==