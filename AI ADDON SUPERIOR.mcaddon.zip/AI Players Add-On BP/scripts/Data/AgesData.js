class AgesData {
}
AgesData.AgePriorities = [
    "wood",
    "stone",
    "torch",
    "copper",
    "iron",
    "diamond",
    "evergreen"
];
AgesData.WoodenAgeRequirements = [
    {
        id: "minecraft:wooden_pickaxe",
        amount: 1
    },
    {
        id: "minecraft:wooden_axe",
        amount: 1
    },
    {
        id: "minecraft:wooden_shovel",
        amount: 1
    },
    {
        id: "minecraft:wooden_sword",
        amount: 1
    }
];
AgesData.StoneAgeRequirements = [
    {
        id: "minecraft:stone_pickaxe",
        amount: 1
    },
    {
        id: "minecraft:stone_axe",
        amount: 1
    },
    {
        id: "minecraft:stone_shovel",
        amount: 1
    },
    {
        id: "minecraft:stone_sword",
        amount: 1
    }
];
AgesData.TorchAgeRequirements = [
    {
        id: "minecraft:torch",
        amount: 32
    }
];
AgesData.CopperAgeRequirements = [
    {
        id: "minecraft:copper_pickaxe",
        amount: 1
    },
    {
        id: "minecraft:copper_axe",
        amount: 1
    },
    {
        id: "minecraft:copper_shovel",
        amount: 1
    },
    {
        id: "minecraft:copper_sword",
        amount: 1
    },
    {
        id: "minecraft:copper_helmet",
        amount: 1
    },
    {
        id: "minecraft:copper_chestplate",
        amount: 1
    },
    {
        id: "minecraft:copper_leggings",
        amount: 1
    },
    {
        id: "minecraft:copper_boots",
        amount: 1
    }
];
AgesData.IronAgeRequirements = [
    {
        id: "minecraft:iron_pickaxe",
        amount: 1
    },
    {
        id: "minecraft:iron_axe",
        amount: 1
    },
    {
        id: "minecraft:iron_shovel",
        amount: 1
    },
    {
        id: "minecraft:iron_sword",
        amount: 1
    },
    {
        id: "minecraft:iron_helmet",
        amount: 1
    },
    {
        id: "minecraft:iron_chestplate",
        amount: 1
    },
    {
        id: "minecraft:iron_leggings",
        amount: 1
    },
    {
        id: "minecraft:iron_boots",
        amount: 1
    }
];
AgesData.DiamondAgeRequirements = [
    {
        id: "minecraft:diamond_pickaxe",
        amount: 1
    },
    {
        id: "minecraft:diamond_axe",
        amount: 1
    },
    {
        id: "minecraft:diamond_shovel",
        amount: 1
    },
    {
        id: "minecraft:diamond_sword",
        amount: 1
    },
    {
        id: "minecraft:diamond_helmet",
        amount: 1
    },
    {
        id: "minecraft:diamond_chestplate",
        amount: 1
    },
    {
        id: "minecraft:diamond_leggings",
        amount: 1
    },
    {
        id: "minecraft:diamond_boots",
        amount: 1
    }
];
AgesData.EvergreenAgeOptions = [
    {
        id: "minecraft:copper_block",
        amount: 1
    },
    {
        id: "minecraft:iron_block",
        amount: 1
    },
    {
        id: "minecraft:gold_block",
        amount: 1
    },
    {
        id: "minecraft:diamond_block",
        amount: 1
    },
    {
        id: "minecraft:lapis_block",
        amount: 1
    },
    {
        id: "minecraft:redstone_block",
        amount: 1
    }
];
AgesData.AgeRequirementsMap = {
    wood: AgesData.WoodenAgeRequirements,
    torch: AgesData.TorchAgeRequirements,
    stone: AgesData.StoneAgeRequirements,
    copper: AgesData.CopperAgeRequirements,
    iron: AgesData.IronAgeRequirements,
    diamond: AgesData.DiamondAgeRequirements,
    evergreen: AgesData.EvergreenAgeOptions
};
export { AgesData as default };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkFnZXNEYXRhLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluZ3JlZGllbnQgfSBmcm9tIFwiLi9DcmFmdGluZ1RyZWVEYXRhXCI7XHJcblxyXG5leHBvcnQgdHlwZSBBZ2UgPSAodHlwZW9mIEFnZXNEYXRhLkFnZVByaW9yaXRpZXMpW251bWJlcl07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBBZ2VzRGF0YSB7XHJcbiAgICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFnZVByaW9yaXRpZXMgPSBbXCJ3b29kXCIsIFwic3RvbmVcIiwgXCJ0b3JjaFwiLCBcImNvcHBlclwiLCBcImlyb25cIiwgXCJkaWFtb25kXCIsIFwiZXZlcmdyZWVuXCJdIGFzIGNvbnN0O1xyXG5cclxuICAgIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgV29vZGVuQWdlUmVxdWlyZW1lbnRzOiBJbmdyZWRpZW50W10gPSBbXHJcbiAgICAgICAgeyBpZDogXCJtaW5lY3JhZnQ6d29vZGVuX3BpY2theGVcIiwgYW1vdW50OiAxIH0sXHJcbiAgICAgICAgeyBpZDogXCJtaW5lY3JhZnQ6d29vZGVuX2F4ZVwiLCBhbW91bnQ6IDEgfSxcclxuICAgICAgICB7IGlkOiBcIm1pbmVjcmFmdDp3b29kZW5fc2hvdmVsXCIsIGFtb3VudDogMSB9LFxyXG4gICAgICAgIHsgaWQ6IFwibWluZWNyYWZ0Ondvb2Rlbl9zd29yZFwiLCBhbW91bnQ6IDEgfSxcclxuICAgIF07XHJcblxyXG4gICAgcHVibGljIHN0YXRpYyByZWFkb25seSBTdG9uZUFnZVJlcXVpcmVtZW50czogSW5ncmVkaWVudFtdID0gW1xyXG4gICAgICAgIHsgaWQ6IFwibWluZWNyYWZ0OnN0b25lX3BpY2theGVcIiwgYW1vdW50OiAxIH0sXHJcbiAgICAgICAgeyBpZDogXCJtaW5lY3JhZnQ6c3RvbmVfYXhlXCIsIGFtb3VudDogMSB9LFxyXG4gICAgICAgIHsgaWQ6IFwibWluZWNyYWZ0OnN0b25lX3Nob3ZlbFwiLCBhbW91bnQ6IDEgfSxcclxuICAgICAgICB7IGlkOiBcIm1pbmVjcmFmdDpzdG9uZV9zd29yZFwiLCBhbW91bnQ6IDEgfSxcclxuICAgIF07XHJcblxyXG4gICAgcHVibGljIHN0YXRpYyByZWFkb25seSBUb3JjaEFnZVJlcXVpcmVtZW50czogSW5ncmVkaWVudFtdID0gW3sgaWQ6IFwibWluZWNyYWZ0OnRvcmNoXCIsIGFtb3VudDogMzIgfV07XHJcblxyXG4gICAgcHVibGljIHN0YXRpYyByZWFkb25seSBDb3BwZXJBZ2VSZXF1aXJlbWVudHM6IEluZ3JlZGllbnRbXSA9IFtcclxuICAgICAgICB7IGlkOiBcIm1pbmVjcmFmdDpjb3BwZXJfcGlja2F4ZVwiLCBhbW91bnQ6IDEgfSxcclxuICAgICAgICB7IGlkOiBcIm1pbmVjcmFmdDpjb3BwZXJfYXhlXCIsIGFtb3VudDogMSB9LFxyXG4gICAgICAgIHsgaWQ6IFwibWluZWNyYWZ0OmNvcHBlcl9zaG92ZWxcIiwgYW1vdW50OiAxIH0sXHJcbiAgICAgICAgeyBpZDogXCJtaW5lY3JhZnQ6Y29wcGVyX3N3b3JkXCIsIGFtb3VudDogMSB9LFxyXG4gICAgICAgIHsgaWQ6IFwibWluZWNyYWZ0OmNvcHBlcl9oZWxtZXRcIiwgYW1vdW50OiAxIH0sXHJcbiAgICAgICAgeyBpZDogXCJtaW5lY3JhZnQ6Y29wcGVyX2NoZXN0cGxhdGVcIiwgYW1vdW50OiAxIH0sXHJcbiAgICAgICAgeyBpZDogXCJtaW5lY3JhZnQ6Y29wcGVyX2xlZ2dpbmdzXCIsIGFtb3VudDogMSB9LFxyXG4gICAgICAgIHsgaWQ6IFwibWluZWNyYWZ0OmNvcHBlcl9ib290c1wiLCBhbW91bnQ6IDEgfSxcclxuICAgIF07XHJcblxyXG4gICAgcHVibGljIHN0YXRpYyByZWFkb25seSBJcm9uQWdlUmVxdWlyZW1lbnRzOiBJbmdyZWRpZW50W10gPSBbXHJcbiAgICAgICAgeyBpZDogXCJtaW5lY3JhZnQ6aXJvbl9waWNrYXhlXCIsIGFtb3VudDogMSB9LFxyXG4gICAgICAgIHsgaWQ6IFwibWluZWNyYWZ0Omlyb25fYXhlXCIsIGFtb3VudDogMSB9LFxyXG4gICAgICAgIHsgaWQ6IFwibWluZWNyYWZ0Omlyb25fc2hvdmVsXCIsIGFtb3VudDogMSB9LFxyXG4gICAgICAgIHsgaWQ6IFwibWluZWNyYWZ0Omlyb25fc3dvcmRcIiwgYW1vdW50OiAxIH0sXHJcbiAgICAgICAgeyBpZDogXCJtaW5lY3JhZnQ6aXJvbl9oZWxtZXRcIiwgYW1vdW50OiAxIH0sXHJcbiAgICAgICAgeyBpZDogXCJtaW5lY3JhZnQ6aXJvbl9jaGVzdHBsYXRlXCIsIGFtb3VudDogMSB9LFxyXG4gICAgICAgIHsgaWQ6IFwibWluZWNyYWZ0Omlyb25fbGVnZ2luZ3NcIiwgYW1vdW50OiAxIH0sXHJcbiAgICAgICAgeyBpZDogXCJtaW5lY3JhZnQ6aXJvbl9ib290c1wiLCBhbW91bnQ6IDEgfSxcclxuICAgIF07XHJcblxyXG4gICAgcHVibGljIHN0YXRpYyByZWFkb25seSBEaWFtb25kQWdlUmVxdWlyZW1lbnRzOiBJbmdyZWRpZW50W10gPSBbXHJcbiAgICAgICAgeyBpZDogXCJtaW5lY3JhZnQ6ZGlhbW9uZF9waWNrYXhlXCIsIGFtb3VudDogMSB9LFxyXG4gICAgICAgIHsgaWQ6IFwibWluZWNyYWZ0OmRpYW1vbmRfYXhlXCIsIGFtb3VudDogMSB9LFxyXG4gICAgICAgIHsgaWQ6IFwibWluZWNyYWZ0OmRpYW1vbmRfc2hvdmVsXCIsIGFtb3VudDogMSB9LFxyXG4gICAgICAgIHsgaWQ6IFwibWluZWNyYWZ0OmRpYW1vbmRfc3dvcmRcIiwgYW1vdW50OiAxIH0sXHJcbiAgICAgICAgeyBpZDogXCJtaW5lY3JhZnQ6ZGlhbW9uZF9oZWxtZXRcIiwgYW1vdW50OiAxIH0sXHJcbiAgICAgICAgeyBpZDogXCJtaW5lY3JhZnQ6ZGlhbW9uZF9jaGVzdHBsYXRlXCIsIGFtb3VudDogMSB9LFxyXG4gICAgICAgIHsgaWQ6IFwibWluZWNyYWZ0OmRpYW1vbmRfbGVnZ2luZ3NcIiwgYW1vdW50OiAxIH0sXHJcbiAgICAgICAgeyBpZDogXCJtaW5lY3JhZnQ6ZGlhbW9uZF9ib290c1wiLCBhbW91bnQ6IDEgfSxcclxuICAgIF07XHJcblxyXG4gICAgcHVibGljIHN0YXRpYyByZWFkb25seSBFdmVyZ3JlZW5BZ2VPcHRpb25zOiBJbmdyZWRpZW50W10gPSBbXHJcbiAgICAgICAgeyBpZDogXCJtaW5lY3JhZnQ6Y29wcGVyX2Jsb2NrXCIsIGFtb3VudDogMSB9LFxyXG4gICAgICAgIHsgaWQ6IFwibWluZWNyYWZ0Omlyb25fYmxvY2tcIiwgYW1vdW50OiAxIH0sXHJcbiAgICAgICAgeyBpZDogXCJtaW5lY3JhZnQ6Z29sZF9ibG9ja1wiLCBhbW91bnQ6IDEgfSxcclxuICAgICAgICB7IGlkOiBcIm1pbmVjcmFmdDpkaWFtb25kX2Jsb2NrXCIsIGFtb3VudDogMSB9LFxyXG4gICAgICAgIHsgaWQ6IFwibWluZWNyYWZ0OmxhcGlzX2Jsb2NrXCIsIGFtb3VudDogMSB9LFxyXG4gICAgICAgIHsgaWQ6IFwibWluZWNyYWZ0OnJlZHN0b25lX2Jsb2NrXCIsIGFtb3VudDogMSB9LFxyXG4gICAgXTtcclxuXHJcbiAgICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFnZVJlcXVpcmVtZW50c01hcDogUGFydGlhbDxSZWNvcmQ8QWdlLCBJbmdyZWRpZW50W10+PiA9IHtcclxuICAgICAgICB3b29kOiBBZ2VzRGF0YS5Xb29kZW5BZ2VSZXF1aXJlbWVudHMsXHJcbiAgICAgICAgdG9yY2g6IEFnZXNEYXRhLlRvcmNoQWdlUmVxdWlyZW1lbnRzLFxyXG4gICAgICAgIHN0b25lOiBBZ2VzRGF0YS5TdG9uZUFnZVJlcXVpcmVtZW50cyxcclxuICAgICAgICBjb3BwZXI6IEFnZXNEYXRhLkNvcHBlckFnZVJlcXVpcmVtZW50cyxcclxuICAgICAgICBpcm9uOiBBZ2VzRGF0YS5Jcm9uQWdlUmVxdWlyZW1lbnRzLFxyXG4gICAgICAgIGRpYW1vbmQ6IEFnZXNEYXRhLkRpYW1vbmRBZ2VSZXF1aXJlbWVudHMsXHJcbiAgICAgICAgZXZlcmdyZWVuOiBBZ2VzRGF0YS5FdmVyZ3JlZW5BZ2VPcHRpb25zLFxyXG4gICAgfTtcclxufVxyXG4iXSwibmFtZXMiOlsiQWdlc0RhdGEiLCJBZ2VQcmlvcml0aWVzIiwiV29vZGVuQWdlUmVxdWlyZW1lbnRzIiwiaWQiLCJhbW91bnQiLCJTdG9uZUFnZVJlcXVpcmVtZW50cyIsIlRvcmNoQWdlUmVxdWlyZW1lbnRzIiwiQ29wcGVyQWdlUmVxdWlyZW1lbnRzIiwiSXJvbkFnZVJlcXVpcmVtZW50cyIsIkRpYW1vbmRBZ2VSZXF1aXJlbWVudHMiLCJFdmVyZ3JlZW5BZ2VPcHRpb25zIiwiQWdlUmVxdWlyZW1lbnRzTWFwIiwid29vZCIsInRvcmNoIiwic3RvbmUiLCJjb3BwZXIiLCJpcm9uIiwiZGlhbW9uZCIsImV2ZXJncmVlbiJdLCJtYXBwaW5ncyI6IkFBSWUsTUFBTUE7QUFzRXJCO0FBdEVxQkEsU0FDTUMsZ0JBQWdCO0lBQUM7SUFBUTtJQUFTO0lBQVM7SUFBVTtJQUFRO0lBQVc7Q0FBWTtBQUQxRkQsU0FHTUUsd0JBQXNDO0lBQ3pEO1FBQUVDLElBQUk7UUFBNEJDLFFBQVE7SUFBRTtJQUM1QztRQUFFRCxJQUFJO1FBQXdCQyxRQUFRO0lBQUU7SUFDeEM7UUFBRUQsSUFBSTtRQUEyQkMsUUFBUTtJQUFFO0lBQzNDO1FBQUVELElBQUk7UUFBMEJDLFFBQVE7SUFBRTtDQUM3QztBQVJnQkosU0FVTUssdUJBQXFDO0lBQ3hEO1FBQUVGLElBQUk7UUFBMkJDLFFBQVE7SUFBRTtJQUMzQztRQUFFRCxJQUFJO1FBQXVCQyxRQUFRO0lBQUU7SUFDdkM7UUFBRUQsSUFBSTtRQUEwQkMsUUFBUTtJQUFFO0lBQzFDO1FBQUVELElBQUk7UUFBeUJDLFFBQVE7SUFBRTtDQUM1QztBQWZnQkosU0FpQk1NLHVCQUFxQztJQUFDO1FBQUVILElBQUk7UUFBbUJDLFFBQVE7SUFBRztDQUFFO0FBakJsRkosU0FtQk1PLHdCQUFzQztJQUN6RDtRQUFFSixJQUFJO1FBQTRCQyxRQUFRO0lBQUU7SUFDNUM7UUFBRUQsSUFBSTtRQUF3QkMsUUFBUTtJQUFFO0lBQ3hDO1FBQUVELElBQUk7UUFBMkJDLFFBQVE7SUFBRTtJQUMzQztRQUFFRCxJQUFJO1FBQTBCQyxRQUFRO0lBQUU7SUFDMUM7UUFBRUQsSUFBSTtRQUEyQkMsUUFBUTtJQUFFO0lBQzNDO1FBQUVELElBQUk7UUFBK0JDLFFBQVE7SUFBRTtJQUMvQztRQUFFRCxJQUFJO1FBQTZCQyxRQUFRO0lBQUU7SUFDN0M7UUFBRUQsSUFBSTtRQUEwQkMsUUFBUTtJQUFFO0NBQzdDO0FBNUJnQkosU0E4Qk1RLHNCQUFvQztJQUN2RDtRQUFFTCxJQUFJO1FBQTBCQyxRQUFRO0lBQUU7SUFDMUM7UUFBRUQsSUFBSTtRQUFzQkMsUUFBUTtJQUFFO0lBQ3RDO1FBQUVELElBQUk7UUFBeUJDLFFBQVE7SUFBRTtJQUN6QztRQUFFRCxJQUFJO1FBQXdCQyxRQUFRO0lBQUU7SUFDeEM7UUFBRUQsSUFBSTtRQUF5QkMsUUFBUTtJQUFFO0lBQ3pDO1FBQUVELElBQUk7UUFBNkJDLFFBQVE7SUFBRTtJQUM3QztRQUFFRCxJQUFJO1FBQTJCQyxRQUFRO0lBQUU7SUFDM0M7UUFBRUQsSUFBSTtRQUF3QkMsUUFBUTtJQUFFO0NBQzNDO0FBdkNnQkosU0F5Q01TLHlCQUF1QztJQUMxRDtRQUFFTixJQUFJO1FBQTZCQyxRQUFRO0lBQUU7SUFDN0M7UUFBRUQsSUFBSTtRQUF5QkMsUUFBUTtJQUFFO0lBQ3pDO1FBQUVELElBQUk7UUFBNEJDLFFBQVE7SUFBRTtJQUM1QztRQUFFRCxJQUFJO1FBQTJCQyxRQUFRO0lBQUU7SUFDM0M7UUFBRUQsSUFBSTtRQUE0QkMsUUFBUTtJQUFFO0lBQzVDO1FBQUVELElBQUk7UUFBZ0NDLFFBQVE7SUFBRTtJQUNoRDtRQUFFRCxJQUFJO1FBQThCQyxRQUFRO0lBQUU7SUFDOUM7UUFBRUQsSUFBSTtRQUEyQkMsUUFBUTtJQUFFO0NBQzlDO0FBbERnQkosU0FvRE1VLHNCQUFvQztJQUN2RDtRQUFFUCxJQUFJO1FBQTBCQyxRQUFRO0lBQUU7SUFDMUM7UUFBRUQsSUFBSTtRQUF3QkMsUUFBUTtJQUFFO0lBQ3hDO1FBQUVELElBQUk7UUFBd0JDLFFBQVE7SUFBRTtJQUN4QztRQUFFRCxJQUFJO1FBQTJCQyxRQUFRO0lBQUU7SUFDM0M7UUFBRUQsSUFBSTtRQUF5QkMsUUFBUTtJQUFFO0lBQ3pDO1FBQUVELElBQUk7UUFBNEJDLFFBQVE7SUFBRTtDQUMvQztBQTNEZ0JKLFNBNkRNVyxxQkFBeUQ7SUFDNUVDLE1BQU1aLFNBQVNFLHFCQUFxQjtJQUNwQ1csT0FBT2IsU0FBU00sb0JBQW9CO0lBQ3BDUSxPQUFPZCxTQUFTSyxvQkFBb0I7SUFDcENVLFFBQVFmLFNBQVNPLHFCQUFxQjtJQUN0Q1MsTUFBTWhCLFNBQVNRLG1CQUFtQjtJQUNsQ1MsU0FBU2pCLFNBQVNTLHNCQUFzQjtJQUN4Q1MsV0FBV2xCLFNBQVNVLG1CQUFtQjtBQUMzQztBQXJFSixTQUFxQlYsc0JBc0VwQiJ9